import React, { useState } from 'react';
import { BotProvider, useBot } from './context/BotContext.tsx';
import { TopBar } from './components/navigation/TopBar.tsx';
import { DiscordSimulator } from './components/simulator/DiscordSimulator.tsx';
import { BotDashboard } from './components/dashboard/BotDashboard.tsx';
import { CommandsLibrary } from './components/commands/CommandsLibrary.tsx';
import { CodeExporter } from './components/code/CodeExporter.tsx';
import { DeveloperGuide } from './components/guide/DeveloperGuide.tsx';
import { LiveWebhookModal } from './components/modals/LiveWebhookModal.tsx';

const AppContent: React.FC = () => {
  const { activeView } = useBot();
  const [webhookModalOpen, setWebhookModalOpen] = useState(false);

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#1e1f22] text-[#dbdee1] select-none font-sans">
      {/* Universal Top Bar Contract */}
      <TopBar onOpenWebhookModal={() => setWebhookModalOpen(true)} />

      {/* Main View Router */}
      <main className="flex-1 flex overflow-hidden w-full relative">
        {activeView === 'simulator' && <DiscordSimulator />}
        {activeView === 'dashboard' && <BotDashboard />}
        {activeView === 'commands' && <CommandsLibrary />}
        {activeView === 'exporter' && <CodeExporter />}
        {activeView === 'developer-guide' && <DeveloperGuide />}
      </main>

      {/* Live Webhook Dispatch Modal */}
      <LiveWebhookModal
        isOpen={webhookModalOpen}
        onClose={() => setWebhookModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <BotProvider>
      <AppContent />
    </BotProvider>
  );
}
