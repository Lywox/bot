import {
  BotConfig,
  DiscordCategory,
  DiscordChannel,
  DiscordMessage,
  DiscordRole,
  DiscordUser,
  ModLogEntry,
  SlashCommand,
  Ticket
} from '../types/discord.ts';

export const DEFAULT_ROLES: DiscordRole[] = [
  { id: 'role_owner', name: 'Server Owner', color: '#F1C40F', hoist: true, position: 8 },
  { id: 'role_admin', name: 'Administrator', color: '#E74C3C', hoist: true, position: 7 },
  { id: 'role_bot', name: 'Aegis App', color: '#5865F2', hoist: true, position: 6 },
  { id: 'role_mod', name: 'Moderator', color: '#3498DB', hoist: true, position: 5 },
  { id: 'role_vip', name: 'VIP Member', color: '#9B59B6', hoist: true, position: 4 },
  { id: 'role_dev', name: 'Developer', color: '#2ECC71', hoist: false, position: 3 },
  { id: 'role_gamer', name: 'Gamer', color: '#E67E22', hoist: false, position: 2 },
  { id: 'role_notifs', name: 'Notification Squad', color: '#1ABC9C', hoist: false, position: 1 },
  { id: 'role_member', name: 'Community Member', color: '#95A5A6', hoist: true, position: 0 },
];

export const DEFAULT_CATEGORIES: DiscordCategory[] = [
  { id: 'cat_info', name: 'INFORMATION' },
  { id: 'cat_chat', name: 'COMMUNITY CHAT' },
  { id: 'cat_bot', name: 'BOT LAB & TOOLS' },
  { id: 'cat_staff', name: 'STAFF & LOGS' },
  { id: 'cat_voice', name: 'VOICE CHANNELS' },
];

export const DEFAULT_USERS: Record<string, DiscordUser> = {
  current_user: {
    id: 'usr_owner',
    username: 'gasimovelbey',
    discriminator: '0001',
    avatarColor: '#5865F2',
    roleId: 'role_owner',
    status: 'online',
    activity: 'Configuring AegisBot',
    joinedAt: 'Jan 12, 2024',
    warnings: 0,
    level: 14,
    xp: 3820,
    balance: 1450,
  },
  bot_user: {
    id: 'usr_bot',
    username: 'AegisBot',
    discriminator: '0001',
    avatarColor: '#5865F2',
    isBot: true,
    roleId: 'role_bot',
    status: 'online',
    activity: '/help | Protecting 1,420 members',
    joinedAt: 'Jan 1, 2024',
    warnings: 0,
    level: 99,
    xp: 99999,
    balance: 999999,
  },
  sarah: {
    id: 'usr_sarah',
    username: 'Sarah_Dev',
    discriminator: '2418',
    avatarColor: '#2ECC71',
    roleId: 'role_admin',
    status: 'idle',
    activity: 'Visual Studio Code',
    joinedAt: 'Feb 10, 2024',
    warnings: 0,
    level: 11,
    xp: 2640,
    balance: 890,
  },
  pixel: {
    id: 'usr_pixel',
    username: 'PixelGamer',
    discriminator: '9041',
    avatarColor: '#E67E22',
    roleId: 'role_gamer',
    status: 'dnd',
    activity: 'Playing Cyberpunk 2077',
    joinedAt: 'Mar 4, 2024',
    warnings: 1,
    level: 8,
    xp: 1430,
    balance: 420,
  },
  echo: {
    id: 'usr_echo',
    username: 'EchoKnight',
    discriminator: '4109',
    avatarColor: '#9B59B6',
    roleId: 'role_vip',
    status: 'online',
    activity: 'Listening to Spotify',
    joinedAt: 'Apr 22, 2024',
    warnings: 0,
    level: 6,
    xp: 980,
    balance: 650,
  },
  novice: {
    id: 'usr_novice',
    username: 'Koa_Rookie',
    discriminator: '7721',
    avatarColor: '#1ABC9C',
    roleId: 'role_member',
    status: 'offline',
    joinedAt: 'Yesterday',
    warnings: 0,
    level: 2,
    xp: 150,
    balance: 100,
  },
};

export const DEFAULT_CHANNELS: DiscordChannel[] = [
  { id: 'c_announcements', name: 'announcements', type: 'announcement', categoryId: 'cat_info', topic: 'Official server news, updates, and bot release notes.' },
  { id: 'c_welcome', name: 'welcome-joins', type: 'text', categoryId: 'cat_info', topic: 'Automatic welcome greetings for newly joined members.' },
  { id: 'c_roles', name: 'reaction-roles', type: 'text', categoryId: 'cat_info', topic: 'Self-assignable roles. Click buttons below to claim roles.' },
  { id: 'c_general', name: 'general', type: 'text', categoryId: 'cat_chat', topic: 'Main server lobby. Be respectful and follow rules.' },
  { id: 'c_bot_cmds', name: 'bot-commands', type: 'text', categoryId: 'cat_bot', topic: 'Test slash commands: /help, /poll, /rank, /daily, /ticket' },
  { id: 'c_tickets', name: 'support-tickets', type: 'text', categoryId: 'cat_bot', topic: 'Need staff assistance? Open a private ticket here.' },
  { id: 'c_mod_logs', name: 'mod-logs', type: 'text', categoryId: 'cat_staff', topic: 'Automated audit log for kicks, bans, mutes, warns, and automod.' },
  { id: 'c_voice_gen', name: 'General Voice', type: 'voice', categoryId: 'cat_voice' },
];

export const DEFAULT_BOT_CONFIG: BotConfig = {
  name: 'AegisBot',
  discriminator: '0001',
  prefix: '!',
  status: 'online',
  activityType: 'PLAYING',
  activityName: '/help | Protecting 1,420 members',
  themeColor: '#5865F2',
  automod: {
    enabled: true,
    antiInvite: true,
    antiLinks: false,
    antiCaps: true,
    capsThreshold: 70,
    badWordsFilter: true,
    badWords: ['scam', 'nitro-free', 'phishing', 'token-grabber', 'hack-discord'],
    antiSpam: true,
    maxWarningsBeforeMute: 3,
    maxWarningsBeforeBan: 5,
  },
  welcome: {
    enabled: true,
    channelId: 'c_welcome',
    title: 'Welcome to Aegis Central!',
    message: 'Hey {user}, welcome aboard to **{server}**! You are member **#{member_count}**. Please read the server rules and pick your roles in #reaction-roles.',
    embedColor: '#5865F2',
    sendDM: false,
    autoRoleId: 'role_member',
  },
  leveling: {
    enabled: true,
    xpPerMessageMin: 15,
    xpPerMessageMax: 25,
    cooldownSeconds: 45,
    channelId: '', // current channel
    levelUpMessage: '🎉 GG {user}, you leveled up to **Level {level}**!',
  },
  economy: {
    enabled: true,
    currencySymbol: '🪙',
    dailyAmount: 150,
    startingBalance: 100,
  },
  tickets: {
    enabled: true,
    channelId: 'c_tickets',
    panelTitle: 'Server Help & Support Desk',
    panelDescription: 'Have a question, report, or billing inquiry? Click the button below to open a private ticket with our staff team.',
    buttonLabel: 'Open Support Ticket',
    buttonColor: 'PRIMARY',
  },
  reactionRoles: [
    {
      id: 'rr_interests',
      channelId: 'c_roles',
      title: 'Pick Your Community Roles',
      description: 'Click the buttons below to toggle your roles on or off instantly:',
      roles: [
        { roleId: 'role_gamer', roleName: 'Gamer', emoji: '🎮', color: '#E67E22' },
        { roleId: 'role_dev', roleName: 'Developer', emoji: '💻', color: '#2ECC71' },
        { roleId: 'role_notifs', roleName: 'Notifications', emoji: '📢', color: '#1ABC9C' },
      ],
    },
  ],
  customCommands: [
    {
      id: 'cmd_rules',
      trigger: 'rules',
      responseType: 'embed',
      content: '1. Be respectful to everyone.\n2. No spam or unapproved advertisements.\n3. Keep topics in their appropriate channels.\n4. Listen to server staff and moderators.',
      embedTitle: '📜 Official Server Rules',
      embedColor: '#3498DB',
    },
    {
      id: 'cmd_website',
      trigger: 'website',
      responseType: 'text',
      content: '🌐 Visit our official website & docs at https://aegisbot.dev for setup guides and commands list!',
    },
  ],
};

export const INITIAL_MESSAGES: DiscordMessage[] = [
  {
    id: 'msg_ann_1',
    channelId: 'c_announcements',
    author: DEFAULT_USERS.bot_user,
    content: '@everyone AegisBot v2.4 has been successfully deployed to the server!',
    timestamp: 'Today at 09:15 AM',
    embeds: [
      {
        title: '🛡️ AegisBot General Suite — Update v2.4 Live',
        description: 'We have updated AegisBot with new high-performance moderation, leveling leaderboards, ticket management, and full slash command parity.',
        color: '#5865F2',
        fields: [
          { name: '✨ What is New?', value: '• Slash commands `/poll`, `/rank`, `/ticket`, `/ban`\n• AutoMod anti-invite and caps protection\n• Real-time Reaction Roles support' },
          { name: '📌 Getting Started', value: 'Type `/help` in <#c_bot_cmds> to explore all 25+ modules!' },
        ],
        footer: { text: 'Aegis Systems • Ready for Production' },
        timestamp: '2026-09-26T09:15:00Z',
      },
    ],
  },
  {
    id: 'msg_welcome_1',
    channelId: 'c_welcome',
    author: DEFAULT_USERS.bot_user,
    content: 'Welcome to the server, <@usr_novice>! 🎉',
    timestamp: 'Yesterday at 04:30 PM',
    embeds: [
      {
        title: '👋 Welcome to Aegis Central!',
        description: 'Welcome <@usr_novice>! You are member **#1,420**.\n\nMake yourself at home, check out our channels, and type `/help` anytime if you need a hand.',
        color: '#57F287',
        fields: [
          { name: '👤 Username', value: '`Koa_Rookie#7721`', inline: true },
          { name: '📅 Account Created', value: '1 year ago', inline: true },
          { name: '🛡️ Assigned Role', value: '@Community Member', inline: true },
        ],
        footer: { text: 'Aegis Welcome Engine' },
      },
    ],
  },
  {
    id: 'msg_gen_1',
    channelId: 'c_general',
    author: DEFAULT_USERS.sarah,
    content: 'Good morning everyone! How is the new bot setup going?',
    timestamp: 'Today at 10:02 AM',
  },
  {
    id: 'msg_gen_2',
    channelId: 'c_general',
    author: DEFAULT_USERS.pixel,
    content: 'Working like a charm! The auto-responder and slash commands are super responsive.',
    timestamp: 'Today at 10:04 AM',
  },
  {
    id: 'msg_gen_3',
    channelId: 'c_general',
    author: DEFAULT_USERS.echo,
    content: 'Just claimed the Gamer and Notifications role from the reaction role channel. Smooth!',
    timestamp: 'Today at 10:12 AM',
  },
  {
    id: 'msg_bot_1',
    channelId: 'c_bot_cmds',
    author: DEFAULT_USERS.bot_user,
    content: 'Welcome to the bot playground! Try typing `/help` or use the command menu below.',
    timestamp: 'Today at 08:00 AM',
    embeds: [
      {
        title: '🤖 AegisBot Command Center',
        description: 'Use slash commands (`/`) or the default prefix (`!`) to interact with the bot.',
        color: '#5865F2',
        fields: [
          { name: '🛡️ Moderation', value: '`/warn`, `/mute`, `/kick`, `/ban`, `/purge`', inline: true },
          { name: '📊 Utility', value: '`/help`, `/serverinfo`, `/userinfo`, `/poll`, `/ping`', inline: true },
          { name: '🪙 Economy & XP', value: '`/rank`, `/leaderboard`, `/daily`, `/coinflip`', inline: true },
        ],
        footer: { text: 'Click any command suggestion to test instantly' },
      },
    ],
    components: [
      {
        components: [
          { type: 'button', id: 'btn_help_all', label: 'View All Commands', style: 'PRIMARY', emoji: '📖' },
          { type: 'button', id: 'btn_check_ping', label: 'Test Ping', style: 'SECONDARY', emoji: '🏓' },
          { type: 'button', id: 'btn_claim_daily', label: 'Claim Daily Coins', style: 'SUCCESS', emoji: '🪙' },
        ],
      },
    ],
  },
  {
    id: 'msg_ticket_panel',
    channelId: 'c_tickets',
    author: DEFAULT_USERS.bot_user,
    content: '',
    timestamp: 'Today at 08:30 AM',
    embeds: [
      {
        title: '🎫 Server Help & Support Desk',
        description: 'Need assistance, want to report a rule breaker, or have a question for server administration?\n\nClick the button below to initiate an encrypted private ticket channel. Our staff team will be with you shortly.',
        color: '#5865F2',
        fields: [
          { name: '⏰ Response Time', value: '< 15 minutes', inline: true },
          { name: '🔒 Privacy', value: 'Only you and Staff can view', inline: true },
        ],
        footer: { text: 'Aegis Ticket System • Powered by Discord Components' },
      },
    ],
    components: [
      {
        components: [
          { type: 'button', id: 'btn_create_ticket', label: 'Open Support Ticket', style: 'PRIMARY', emoji: '📩' },
        ],
      },
    ],
  },
  {
    id: 'msg_roles_panel',
    channelId: 'c_roles',
    author: DEFAULT_USERS.bot_user,
    content: '',
    timestamp: 'Today at 08:35 AM',
    embeds: [
      {
        title: '🎭 Pick Your Community Roles',
        description: 'Select your preferred interest and ping roles below. Clicking a button will instantly grant or remove the corresponding role on your profile.',
        color: '#9B59B6',
        fields: [
          { name: '🎮 Gamer', value: 'Get pinged for gaming sessions & tournament lobbies', inline: false },
          { name: '💻 Developer', value: 'Access coding channels and bot developer discussion', inline: false },
          { name: '📢 Notification Squad', value: 'Receive pings for major events, giveaways & announcements', inline: false },
        ],
        footer: { text: 'Aegis Reaction Roles' },
      },
    ],
    components: [
      {
        components: [
          { type: 'button', id: 'btn_role_gamer', label: 'Gamer', style: 'SECONDARY', emoji: '🎮' },
          { type: 'button', id: 'btn_role_dev', label: 'Developer', style: 'SECONDARY', emoji: '💻' },
          { type: 'button', id: 'btn_role_notifs', label: 'Notification Squad', style: 'SECONDARY', emoji: '📢' },
        ],
      },
    ],
  },
  {
    id: 'msg_mod_1',
    channelId: 'c_mod_logs',
    author: DEFAULT_USERS.bot_user,
    content: '',
    timestamp: 'Yesterday at 07:42 PM',
    embeds: [
      {
        title: '🛡️ Case #104 | Action: WARN',
        description: 'A user received an official moderation warning.',
        color: '#FEE75C',
        fields: [
          { name: 'User', value: '<@usr_pixel> (`usr_pixel`)', inline: true },
          { name: 'Moderator', value: '<@usr_owner>', inline: true },
          { name: 'Reason', value: 'Excessive caps in #general channel', inline: false },
          { name: 'Current Warnings', value: '1 / 3', inline: true },
        ],
        footer: { text: 'Aegis Moderation Audit' },
        timestamp: '2026-09-25T19:42:00Z',
      },
    ],
  },
];

export const INITIAL_MOD_LOGS: ModLogEntry[] = [
  {
    id: 'log_1',
    caseNumber: 104,
    action: 'WARN',
    targetUser: 'PixelGamer#9041',
    targetId: 'usr_pixel',
    moderator: 'gasimovelbey',
    reason: 'Excessive caps in #general channel',
    timestamp: 'Yesterday at 07:42 PM',
  },
  {
    id: 'log_2',
    caseNumber: 103,
    action: 'PURGE',
    targetUser: '15 messages',
    targetId: 'c_general',
    moderator: 'Sarah_Dev',
    reason: 'Cleaned off-topic spam messages',
    timestamp: '2 days ago at 03:15 PM',
  },
];

export const INITIAL_TICKETS: Ticket[] = [
  {
    id: 't_101',
    number: 101,
    creatorId: 'usr_echo',
    creatorName: 'EchoKnight',
    channelId: 'c_ticket_101',
    status: 'OPEN',
    createdAt: 'Today at 09:40 AM',
    topic: 'Assistance with VIP role perks and custom color',
  },
];

export const ALL_SLASH_COMMANDS: SlashCommand[] = [
  // Moderation
  {
    name: 'warn',
    description: 'Issue an official moderation warning to a server member',
    category: 'Moderation',
    syntax: '/warn <user> [reason]',
    example: '/warn @PixelGamer Excessive spamming',
    userPermissions: ['Moderate Members'],
    options: [
      { name: 'user', description: 'The member to warn', required: true, type: 'User' },
      { name: 'reason', description: 'Reason for the warning', required: false, type: 'String' },
    ],
  },
  {
    name: 'mute',
    description: 'Timeout / mute a member for a specified duration',
    category: 'Moderation',
    syntax: '/mute <user> <duration> [reason]',
    example: '/mute @BadActor 10m Inappropriate language',
    userPermissions: ['Moderate Members'],
    options: [
      { name: 'user', description: 'Member to mute', required: true, type: 'User' },
      { name: 'duration', description: 'Duration (e.g. 5m, 1h, 1d)', required: true, type: 'String' },
      { name: 'reason', description: 'Reason for timeout', required: false, type: 'String' },
    ],
  },
  {
    name: 'unmute',
    description: 'Remove timeout / unmute a member early',
    category: 'Moderation',
    syntax: '/unmute <user>',
    example: '/unmute @Member',
    userPermissions: ['Moderate Members'],
    options: [{ name: 'user', description: 'Member to unmute', required: true, type: 'User' }],
  },
  {
    name: 'kick',
    description: 'Kick a member from the server with audit logging',
    category: 'Moderation',
    syntax: '/kick <user> [reason]',
    example: '/kick @RuleBreaker Ignoring mod instructions',
    userPermissions: ['Kick Members'],
    options: [
      { name: 'user', description: 'Member to kick', required: true, type: 'User' },
      { name: 'reason', description: 'Reason for kick', required: false, type: 'String' },
    ],
  },
  {
    name: 'ban',
    description: 'Permanently ban a user from the server',
    category: 'Moderation',
    syntax: '/ban <user> [reason]',
    example: '/ban @Scammer Phishing links',
    userPermissions: ['Ban Members'],
    options: [
      { name: 'user', description: 'User to ban', required: true, type: 'User' },
      { name: 'reason', description: 'Reason for ban', required: false, type: 'String' },
    ],
  },
  {
    name: 'purge',
    description: 'Bulk delete a specified number of recent messages',
    category: 'Moderation',
    syntax: '/purge <amount>',
    example: '/purge 20',
    userPermissions: ['Manage Messages'],
    options: [{ name: 'amount', description: 'Number of messages (1-100)', required: true, type: 'Integer' }],
  },

  // Utility
  {
    name: 'help',
    description: 'List all available bot modules, commands, and syntax',
    category: 'Utility',
    syntax: '/help [category]',
    example: '/help moderation',
  },
  {
    name: 'ping',
    description: 'Check bot gateway latency, API latency, and uptime',
    category: 'Utility',
    syntax: '/ping',
    example: '/ping',
  },
  {
    name: 'serverinfo',
    description: 'Display server statistics, member counts, boost tier, and roles',
    category: 'Utility',
    syntax: '/serverinfo',
    example: '/serverinfo',
  },
  {
    name: 'userinfo',
    description: 'Display user account details, join date, roles, and status',
    category: 'Utility',
    syntax: '/userinfo [user]',
    example: '/userinfo @Sarah_Dev',
  },
  {
    name: 'avatar',
    description: 'Display full-resolution avatar of yourself or a member',
    category: 'Utility',
    syntax: '/avatar [user]',
    example: '/avatar @EchoKnight',
  },
  {
    name: 'poll',
    description: 'Create an interactive server poll with reaction voting',
    category: 'Utility',
    syntax: '/poll <question> <option1> <option2>',
    example: '/poll "Next movie night?" "Interstellar" "Inception"',
  },
  {
    name: 'remind',
    description: 'Set a custom reminder timer with DM or channel ping',
    category: 'Utility',
    syntax: '/remind <time> <message>',
    example: '/remind 10m Check the server deployment',
  },
  {
    name: 'calc',
    description: 'Quick math calculator',
    category: 'Utility',
    syntax: '/calc <expression>',
    example: '/calc (45 * 12) / 2',
  },

  // Leveling & Economy
  {
    name: 'rank',
    description: 'View your current level, XP progress card, and global rank',
    category: 'Leveling & Economy',
    syntax: '/rank [user]',
    example: '/rank @gasimovelbey',
  },
  {
    name: 'leaderboard',
    description: 'Show top 10 most active members ranked by XP & level',
    category: 'Leveling & Economy',
    syntax: '/leaderboard',
    example: '/leaderboard',
  },
  {
    name: 'daily',
    description: 'Claim your free daily coin allowance (every 24 hours)',
    category: 'Leveling & Economy',
    syntax: '/daily',
    example: '/daily',
  },
  {
    name: 'balance',
    description: 'Check your wallet balance and bank holdings',
    category: 'Leveling & Economy',
    syntax: '/balance [user]',
    example: '/balance',
  },
  {
    name: 'coinflip',
    description: 'Bet coins on Heads or Tails to double your stake',
    category: 'Leveling & Economy',
    syntax: '/coinflip <heads|tails> <amount>',
    example: '/coinflip heads 50',
  },

  // Engagement & Fun
  {
    name: '8ball',
    description: 'Ask the magic 8-ball a question and get a prophetic answer',
    category: 'Engagement & Fun',
    syntax: '/8ball <question>',
    example: '/8ball Will our Discord server reach 10,000 members?',
  },
  {
    name: 'roll',
    description: 'Roll dice (e.g. 1d6, 2d20, 1d100)',
    category: 'Engagement & Fun',
    syntax: '/roll [dice]',
    example: '/roll 2d6',
  },
  {
    name: 'choose',
    description: 'Let the bot pick randomly between multiple choices',
    category: 'Engagement & Fun',
    syntax: '/choose <choice1> | <choice2> | [choice3]',
    example: '/choose Pizza | Burgers | Tacos',
  },

  // Support
  {
    name: 'ticket',
    description: 'Create a private staff support ticket',
    category: 'Tickets & Support',
    syntax: '/ticket [subject]',
    example: '/ticket Help with server booster role',
  },
  {
    name: 'close',
    description: 'Close an active ticket and generate chat transcript',
    category: 'Tickets & Support',
    syntax: '/close [reason]',
    example: '/close Issue resolved',
    userPermissions: ['Manage Channels'],
  },
];
