import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  BotConfig,
  DiscordChannel,
  DiscordMessage,
  DiscordRole,
  DiscordUser,
  ModLogEntry,
  SlashCommand,
  Ticket,
  CustomCommand,
  DiscordEmbed
} from '../types/discord.ts';
import {
  ALL_SLASH_COMMANDS,
  DEFAULT_BOT_CONFIG,
  DEFAULT_CHANNELS,
  DEFAULT_ROLES,
  DEFAULT_USERS,
  INITIAL_MESSAGES,
  INITIAL_MOD_LOGS,
  INITIAL_TICKETS
} from '../data/defaultData.ts';

interface BotContextType {
  botConfig: BotConfig;
  setBotConfig: React.Dispatch<React.SetStateAction<BotConfig>>;
  channels: DiscordChannel[];
  activeChannelId: string;
  setActiveChannelId: (id: string) => void;
  users: Record<string, DiscordUser>;
  currentUser: DiscordUser;
  roles: DiscordRole[];
  messages: DiscordMessage[];
  modLogs: ModLogEntry[];
  tickets: Ticket[];
  isTyping: boolean;
  activeView: 'simulator' | 'dashboard' | 'commands' | 'exporter' | 'developer-guide';
  setActiveView: (view: 'simulator' | 'dashboard' | 'commands' | 'exporter' | 'developer-guide') => void;
  sendMessage: (content: string, options?: { channelId?: string }) => void;
  handleComponentClick: (componentId: string, messageId: string) => void;
  simulateMemberChat: () => void;
  simulateMemberJoin: (customName?: string) => void;
  toggleUserRole: (userId: string, roleId: string) => void;
  clearChannelMessages: (channelId: string) => void;
  addCustomCommand: (command: CustomCommand) => void;
  removeCustomCommand: (id: string) => void;
  revokeModCase: (caseId: string) => void;
  sendLiveWebhook: (url: string, content: string, title?: string, color?: string) => Promise<{ success: boolean; message: string }>;
}

const BotContext = createContext<BotContextType | null>(null);

export const BotProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [botConfig, setBotConfig] = useState<BotConfig>(DEFAULT_BOT_CONFIG);
  const [channels, setChannels] = useState<DiscordChannel[]>(DEFAULT_CHANNELS);
  const [activeChannelId, setActiveChannelId] = useState<string>('c_general');
  const [users, setUsers] = useState<Record<string, DiscordUser>>(DEFAULT_USERS);
  const [roles] = useState<DiscordRole[]>(DEFAULT_ROLES);
  const [messages, setMessages] = useState<DiscordMessage[]>(INITIAL_MESSAGES);
  const [modLogs, setModLogs] = useState<ModLogEntry[]>(INITIAL_MOD_LOGS);
  const [tickets, setTickets] = useState<Ticket[]>(INITIAL_TICKETS);
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [activeView, setActiveView] = useState<'simulator' | 'dashboard' | 'commands' | 'exporter' | 'developer-guide'>('simulator');

  const currentUser = users['current_user'];
  const botUser = users['bot_user'];

  // Keep bot status & activity updated in botUser
  useEffect(() => {
    setUsers(prev => ({
      ...prev,
      bot_user: {
        ...prev.bot_user,
        username: botConfig.name,
        discriminator: botConfig.discriminator,
        status: botConfig.status,
        activity: `${botConfig.activityType.toLowerCase()} ${botConfig.activityName}`,
      }
    }));
  }, [botConfig]);

  // Helper to format timestamps
  const getFormattedTime = () => {
    const now = new Date();
    return `Today at ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  };

  // Helper to add bot message with typing delay
  const addBotMessage = (
    channelId: string,
    content: string,
    embeds?: DiscordEmbed[],
    components?: DiscordMessage['components'],
    delayMs = 600
  ) => {
    setIsTyping(true);
    setTimeout(() => {
      const newMsg: DiscordMessage = {
        id: `msg_bot_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        channelId,
        author: {
          ...botUser,
          username: botConfig.name,
          discriminator: botConfig.discriminator,
        },
        content,
        timestamp: getFormattedTime(),
        embeds,
        components,
      };
      setMessages(prev => [...prev, newMsg]);
      setIsTyping(false);
    }, delayMs);
  };

  // Log a mod action
  const logModAction = (action: ModLogEntry['action'], targetUser: string, targetId: string, moderator: string, reason: string) => {
    const caseNumber = modLogs.length > 0 ? Math.max(...modLogs.map(l => l.caseNumber)) + 1 : 101;
    const newEntry: ModLogEntry = {
      id: `log_${Date.now()}`,
      caseNumber,
      action,
      targetUser,
      targetId,
      moderator,
      reason,
      timestamp: getFormattedTime(),
    };
    setModLogs(prev => [newEntry, ...prev]);

    // Send embed to mod-logs channel
    const colorMap: Record<string, string> = {
      WARN: '#FEE75C',
      MUTE: '#E67E22',
      UNMUTE: '#57F287',
      KICK: '#ED4245',
      BAN: '#ED4245',
      UNBAN: '#57F287',
      PURGE: '#3498DB',
    };

    addBotMessage(
      'c_mod_logs',
      '',
      [
        {
          title: `🛡️ Case #${caseNumber} | Action: ${action}`,
          description: `An official moderation action was executed by staff.`,
          color: colorMap[action] || '#5865F2',
          fields: [
            { name: 'Target', value: `\`${targetUser}\``, inline: true },
            { name: 'Moderator', value: `\`${moderator}\``, inline: true },
            { name: 'Reason', value: reason, inline: false },
          ],
          footer: { text: 'Aegis Moderation Audit System' },
          timestamp: new Date().toISOString(),
        },
      ],
      undefined,
      400
    );
  };

  // Execute Slash & Prefix Commands
  const executeCommand = (rawInput: string, channelId: string) => {
    const clean = rawInput.trim();
    const isSlash = clean.startsWith('/');
    const isPrefix = clean.startsWith(botConfig.prefix);

    if (!isSlash && !isPrefix) return false;

    const commandText = isSlash ? clean.slice(1) : clean.slice(botConfig.prefix.length);
    const parts = commandText.split(' ');
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    switch (cmd) {
      case 'ping': {
        const pingMs = Math.floor(Math.random() * 14) + 18;
        const apiMs = Math.floor(Math.random() * 20) + 32;
        addBotMessage(channelId, '', [
          {
            title: '🏓 Pong!',
            color: '#57F287',
            fields: [
              { name: 'Gateway Latency', value: `\`${pingMs}ms\``, inline: true },
              { name: 'API Latency', value: `\`${apiMs}ms\``, inline: true },
              { name: 'Uptime', value: '`99.98%` (42d 16h)', inline: true },
            ],
            footer: { text: `${botConfig.name} System Status` },
          },
        ]);
        return true;
      }

      case 'help': {
        const categoryArg = args[0]?.toLowerCase();
        if (categoryArg) {
          const filtered = ALL_SLASH_COMMANDS.filter(c => c.category.toLowerCase().includes(categoryArg));
          if (filtered.length > 0) {
            addBotMessage(channelId, '', [
              {
                title: `📖 Help: ${filtered[0].category}`,
                description: `Displaying commands available in this category:`,
                color: '#5865F2',
                fields: filtered.map(c => ({
                  name: `\`${c.syntax}\``,
                  value: `${c.description}\n*Example:* \`${c.example}\``,
                  inline: false,
                })),
              },
            ]);
            return true;
          }
        }

        addBotMessage(
          channelId,
          '',
          [
            {
              title: `🛡️ ${botConfig.name} — Command Manual & Guide`,
              description: `Here is the comprehensive commands catalog. Type \`/help <category>\` or click the buttons below for deep details.`,
              color: '#5865F2',
              fields: [
                { name: '🛡️ Moderation', value: '`/warn`, `/mute`, `/unmute`, `/kick`, `/ban`, `/purge`', inline: true },
                { name: '📊 Utility', value: '`/help`, `/ping`, `/serverinfo`, `/userinfo`, `/poll`, `/avatar`', inline: true },
                { name: '🪙 Economy & XP', value: '`/rank`, `/leaderboard`, `/daily`, `/balance`, `/coinflip`', inline: true },
                { name: '🎉 Engagement', value: '`/8ball`, `/roll`, `/choose`', inline: true },
                { name: '🎫 Tickets', value: '`/ticket`, `/close`', inline: true },
                { name: '⚙️ Configuration', value: 'Adjust via web dashboard or `!rules`, `!website`', inline: true },
              ],
              footer: { text: `Prefix: ${botConfig.prefix} | Slash commands fully supported` },
            },
          ],
          [
            {
              components: [
                { type: 'button', id: 'btn_help_mod', label: 'Moderation', style: 'SECONDARY', emoji: '🛡️' },
                { type: 'button', id: 'btn_help_util', label: 'Utility', style: 'SECONDARY', emoji: '📊' },
                { type: 'button', id: 'btn_help_econ', label: 'Leveling & XP', style: 'SECONDARY', emoji: '🪙' },
              ],
            },
          ]
        );
        return true;
      }

      case 'serverinfo': {
        addBotMessage(channelId, '', [
          {
            title: '📊 Aegis Central — Server Information',
            description: 'The premier community testing grounds for general Discord bot deployment.',
            color: '#5865F2',
            fields: [
              { name: '👑 Server Owner', value: '<@usr_owner>', inline: true },
              { name: '👥 Total Members', value: '**1,420** (384 online)', inline: true },
              { name: '🚀 Boost Level', value: 'Level 3 (18 Boosts)', inline: true },
              { name: '💬 Channels', value: `${channels.length} (Text & Voice)`, inline: true },
              { name: '🎭 Roles', value: `${roles.length} Roles`, inline: true },
              { name: '📅 Creation Date', value: 'January 1, 2024', inline: true },
              { name: '🔒 Verification Level', value: 'Medium (5 min wait)', inline: true },
              { name: '🛡️ AutoMod', value: botConfig.automod.enabled ? '🟢 Active' : '🔴 Disabled', inline: true },
            ],
            footer: { text: 'Server ID: 109283746592837465' },
          },
        ]);
        return true;
      }

      case 'userinfo': {
        const targetUsername = args[0]?.replace('@', '') || currentUser.username;
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetUsername.toLowerCase())) || currentUser;
        const userRole = roles.find(r => r.id === targetUser.roleId);

        addBotMessage(channelId, '', [
          {
            title: `👤 User Profile: ${targetUser.username}#${targetUser.discriminator}`,
            color: userRole?.color || '#5865F2',
            fields: [
              { name: 'ID', value: `\`${targetUser.id}\``, inline: true },
              { name: 'Status', value: `${targetUser.status.toUpperCase()}`, inline: true },
              { name: 'Primary Role', value: userRole ? `@${userRole.name}` : '@Member', inline: true },
              { name: 'Joined Server', value: targetUser.joinedAt, inline: true },
              { name: 'Level & XP', value: `Level **${targetUser.level}** (${targetUser.xp} XP)`, inline: true },
              { name: 'Balance', value: `${botConfig.economy.currencySymbol} ${targetUser.balance}`, inline: true },
              { name: 'Active Warnings', value: `${targetUser.warnings} warning(s)`, inline: true },
            ],
            footer: { text: targetUser.isBot ? 'Verified Bot Application' : 'Human Member' },
          },
        ]);
        return true;
      }

      case 'avatar': {
        const targetUsername = args[0]?.replace('@', '') || currentUser.username;
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetUsername.toLowerCase())) || currentUser;

        addBotMessage(channelId, '', [
          {
            title: `🖼️ Avatar for ${targetUser.username}`,
            description: `[Direct PNG Link](https://discord.com/users/${targetUser.id}) • Resolution: 1024x1024`,
            color: '#5865F2',
            fields: [
              { name: 'User Identifier', value: `\`${targetUser.username}#${targetUser.discriminator}\`` },
            ],
            footer: { text: 'Requested via Discord Slash Command' },
          },
        ]);
        return true;
      }

      case 'warn': {
        const targetName = args[0]?.replace('@', '') || 'PixelGamer';
        const reason = args.slice(1).join(' ') || 'Disruptive behavior in general chat';
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetName.toLowerCase())) || users.pixel;

        // update warning count
        setUsers(prev => {
          const userKey = Object.keys(prev).find(k => prev[k].id === targetUser.id);
          if (!userKey) return prev;
          return {
            ...prev,
            [userKey]: { ...prev[userKey], warnings: prev[userKey].warnings + 1 }
          };
        });

        const newCount = targetUser.warnings + 1;
        logModAction('WARN', `${targetUser.username}#${targetUser.discriminator}`, targetUser.id, currentUser.username, reason);

        addBotMessage(channelId, '', [
          {
            title: '⚠️ Moderation Warning Issued',
            color: '#FEE75C',
            fields: [
              { name: 'Member Warned', value: `<@${targetUser.id}> (\`${targetUser.username}\`)`, inline: true },
              { name: 'Moderator', value: `<@${currentUser.id}>`, inline: true },
              { name: 'Reason', value: reason, inline: false },
              { name: 'Total Warnings', value: `\`${newCount} / ${botConfig.automod.maxWarningsBeforeMute}\``, inline: true },
            ],
            footer: { text: newCount >= botConfig.automod.maxWarningsBeforeMute ? '⚠️ Warning threshold met! User eligible for timeout.' : 'Please adhere to the server rules' },
          },
        ]);
        return true;
      }

      case 'mute':
      case 'timeout': {
        const targetName = args[0]?.replace('@', '') || 'PixelGamer';
        const duration = args[1] || '10m';
        const reason = args.slice(2).join(' ') || 'Excessive spamming / rule violation';
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetName.toLowerCase())) || users.pixel;

        logModAction('MUTE', `${targetUser.username}#${targetUser.discriminator}`, targetUser.id, currentUser.username, `${reason} (${duration})`);

        addBotMessage(channelId, '', [
          {
            title: '🔇 Member Timed Out',
            color: '#E67E22',
            fields: [
              { name: 'Member', value: `<@${targetUser.id}>`, inline: true },
              { name: 'Duration', value: `\`${duration}\``, inline: true },
              { name: 'Moderator', value: `<@${currentUser.id}>`, inline: true },
              { name: 'Reason', value: reason, inline: false },
            ],
            footer: { text: 'Member cannot send messages or join voice channels during timeout' },
          },
        ]);
        return true;
      }

      case 'unmute': {
        const targetName = args[0]?.replace('@', '') || 'PixelGamer';
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetName.toLowerCase())) || users.pixel;

        logModAction('UNMUTE', `${targetUser.username}#${targetUser.discriminator}`, targetUser.id, currentUser.username, 'Timeout removed early by moderator');

        addBotMessage(channelId, '', [
          {
            title: '🔊 Member Timeout Removed',
            description: `<@${targetUser.id}> timeout has been cancelled. They may now participate normally.`,
            color: '#57F287',
          },
        ]);
        return true;
      }

      case 'kick': {
        const targetName = args[0]?.replace('@', '') || 'Koa_Rookie';
        const reason = args.slice(1).join(' ') || 'Violating server code of conduct';
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetName.toLowerCase())) || users.novice;

        logModAction('KICK', `${targetUser.username}#${targetUser.discriminator}`, targetUser.id, currentUser.username, reason);

        addBotMessage(channelId, '', [
          {
            title: '👢 Member Kicked from Server',
            color: '#ED4245',
            fields: [
              { name: 'Kicked Member', value: `\`${targetUser.username}#${targetUser.discriminator}\``, inline: true },
              { name: 'Moderator', value: `<@${currentUser.id}>`, inline: true },
              { name: 'Reason', value: reason, inline: false },
            ],
          },
        ]);
        return true;
      }

      case 'ban': {
        const targetName = args[0]?.replace('@', '') || 'SuspiciousUser';
        const reason = args.slice(1).join(' ') || 'Phishing / malicious links';

        logModAction('BAN', `${targetName}#9999`, 'usr_banned', currentUser.username, reason);

        addBotMessage(channelId, '', [
          {
            title: '🔨 Member Permanently Banned',
            description: `The user **${targetName}** has been banned from the server and messages from the past 24 hours have been deleted.`,
            color: '#ED4245',
            fields: [
              { name: 'Moderator', value: `<@${currentUser.id}>`, inline: true },
              { name: 'Reason', value: reason, inline: true },
            ],
            footer: { text: 'Audit log entry logged to #mod-logs' },
          },
        ]);
        return true;
      }

      case 'purge':
      case 'clear': {
        const count = parseInt(args[0], 10) || 5;
        const validCount = Math.min(Math.max(count, 1), 50);

        setMessages(prev => {
          const currentChannelMsgs = prev.filter(m => m.channelId === channelId);
          const otherMsgs = prev.filter(m => m.channelId !== channelId);
          const remaining = currentChannelMsgs.slice(0, Math.max(0, currentChannelMsgs.length - validCount));
          return [...otherMsgs, ...remaining];
        });

        logModAction('PURGE', `${validCount} messages`, channelId, currentUser.username, `Cleaned ${validCount} messages in channel`);

        addBotMessage(channelId, `🧹 Successfully deleted **${validCount}** messages from this channel.`, undefined, undefined, 300);
        return true;
      }

      case 'poll': {
        const pollQuestion = args.join(' ') || 'Should we host a community gaming night this Friday?';
        addBotMessage(
          channelId,
          '',
          [
            {
              title: '📊 Community Poll',
              description: `**${pollQuestion}**\n\nVote by clicking one of the buttons below:`,
              color: '#3498DB',
              fields: [
                { name: 'Option 1: ✅ Yes / In favor', value: '`1 vote`', inline: true },
                { name: 'Option 2: ❌ No / Disagree', value: '`0 votes`', inline: true },
              ],
              footer: { text: `Poll created by ${currentUser.username} • Live voting` },
            },
          ],
          [
            {
              components: [
                { type: 'button', id: 'btn_poll_yes', label: 'Vote Yes (✅)', style: 'SUCCESS' },
                { type: 'button', id: 'btn_poll_no', label: 'Vote No (❌)', style: 'DANGER' },
              ],
            },
          ]
        );
        return true;
      }

      case 'rank':
      case 'level': {
        const targetName = args[0]?.replace('@', '') || currentUser.username;
        const targetUser = Object.values(users).find(u => u.username.toLowerCase().includes(targetName.toLowerCase())) || currentUser;
        const nextLevelXp = targetUser.level * 250;
        const progressPercent = Math.min(Math.round((targetUser.xp % 250) / 2.5), 100);

        addBotMessage(channelId, '', [
          {
            title: `🏆 Rank Card — ${targetUser.username}`,
            color: '#F1C40F',
            fields: [
              { name: 'Rank', value: '#1 (Server Top)', inline: true },
              { name: 'Level', value: `**${targetUser.level}**`, inline: true },
              { name: 'Total XP', value: `\`${targetUser.xp.toLocaleString()} XP\``, inline: true },
              {
                name: 'Level Progress',
                value: `[${'█'.repeat(Math.floor(progressPercent / 10))}${'░'.repeat(10 - Math.floor(progressPercent / 10))}] ${progressPercent}%\n*Next Level at ${nextLevelXp} XP*`,
                inline: false,
              },
            ],
            footer: { text: 'Chat actively to earn 15-25 XP per message!' },
          },
        ]);
        return true;
      }

      case 'leaderboard':
      case 'top': {
        const sorted = Object.values(users)
          .filter(u => !u.isBot)
          .sort((a, b) => b.xp - a.xp);

        addBotMessage(channelId, '', [
          {
            title: '🏅 Server XP & Activity Leaderboard',
            description: 'Top contributors ranked by total earned experience points:',
            color: '#F1C40F',
            fields: sorted.map((u, i) => ({
              name: `${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`} ${u.username}`,
              value: `Level **${u.level}** · \`${u.xp.toLocaleString()} XP\` · ${botConfig.economy.currencySymbol} ${u.balance}`,
              inline: false,
            })),
            footer: { text: 'Leaderboard updates continuously with every chat interaction' },
          },
        ]);
        return true;
      }

      case 'daily': {
        const reward = botConfig.economy.dailyAmount;
        setUsers(prev => ({
          ...prev,
          current_user: {
            ...prev.current_user,
            balance: prev.current_user.balance + reward,
          },
        }));

        addBotMessage(channelId, '', [
          {
            title: '🪙 Daily Reward Claimed!',
            description: `You received your daily reward of **${botConfig.economy.currencySymbol} ${reward} coins**!\n\nYour new balance is **${botConfig.economy.currencySymbol} ${currentUser.balance + reward}**.`,
            color: '#FEE75C',
            footer: { text: 'Come back in 24 hours for your next streak bonus!' },
          },
        ]);
        return true;
      }

      case 'balance':
      case 'bal': {
        addBotMessage(channelId, '', [
          {
            title: `💰 Wallet & Bank: ${currentUser.username}`,
            color: '#2ECC71',
            fields: [
              { name: 'Wallet Balance', value: `**${botConfig.economy.currencySymbol} ${currentUser.balance.toLocaleString()}**`, inline: true },
              { name: 'Bank Holdings', value: `**${botConfig.economy.currencySymbol} ${(currentUser.balance * 2.5).toFixed(0)}**`, inline: true },
              { name: 'Net Worth', value: `**${botConfig.economy.currencySymbol} ${(currentUser.balance * 3.5).toFixed(0)}**`, inline: true },
            ],
            footer: { text: 'Use /daily, /coinflip, or chat to earn more!' },
          },
        ]);
        return true;
      }

      case 'coinflip': {
        const choice = (args[0] || 'heads').toLowerCase();
        const betAmount = parseInt(args[1], 10) || 50;
        const outcome = Math.random() > 0.5 ? 'heads' : 'tails';
        const won = choice.startsWith(outcome[0]);

        setUsers(prev => ({
          ...prev,
          current_user: {
            ...prev.current_user,
            balance: won ? prev.current_user.balance + betAmount : Math.max(0, prev.current_user.balance - betAmount),
          },
        }));

        addBotMessage(channelId, '', [
          {
            title: won ? '🎉 You Won the Coinflip!' : '💸 Better Luck Next Time!',
            description: `The coin landed on **${outcome.toUpperCase()}**!\n${won ? `You won **${botConfig.economy.currencySymbol} ${betAmount}**!` : `You lost **${botConfig.economy.currencySymbol} ${betAmount}**.`}`,
            color: won ? '#57F287' : '#ED4245',
            footer: { text: `New balance: ${botConfig.economy.currencySymbol} ${won ? currentUser.balance + betAmount : Math.max(0, currentUser.balance - betAmount)}` },
          },
        ]);
        return true;
      }

      case '8ball': {
        const question = args.join(' ');
        const answers = [
          'It is certain.',
          'Without a doubt.',
          'Yes - definitely.',
          'You may rely on it.',
          'Most likely.',
          'Outlook good.',
          'Reply hazy, try again.',
          'Ask again later.',
          'Better not tell you now.',
          'Cannot predict now.',
          'Do not count on it.',
          'My reply is no.',
          'My sources say no.',
          'Outlook not so good.',
          'Very doubtful.',
        ];
        const randomAnswer = answers[Math.floor(Math.random() * answers.length)];

        addBotMessage(channelId, '', [
          {
            title: '🎱 Magic 8-Ball',
            color: '#9B59B6',
            fields: [
              { name: 'Question', value: question || 'Will today be a great day?', inline: false },
              { name: 'Answer', value: `*${randomAnswer}*`, inline: false },
            ],
          },
        ]);
        return true;
      }

      case 'roll': {
        const rollResult = Math.floor(Math.random() * 6) + 1;
        const secondResult = Math.floor(Math.random() * 6) + 1;
        addBotMessage(channelId, `🎲 You rolled **${rollResult}** and **${secondResult}** (Total: **${rollResult + secondResult}**)`);
        return true;
      }

      case 'choose': {
        const rawChoices = args.join(' ').split('|');
        const choices = rawChoices.map(c => c.trim()).filter(Boolean);
        if (choices.length < 2) {
          addBotMessage(channelId, '⚠️ Please provide at least 2 choices separated by `|` (e.g. `/choose Pizza | Burgers | Tacos`)');
          return true;
        }
        const picked = choices[Math.floor(Math.random() * choices.length)];
        addBotMessage(channelId, `🤔 I choose: **${picked}**!`);
        return true;
      }

      case 'ticket': {
        const topic = args.join(' ') || 'General inquiry and support';
        const ticketNum = tickets.length > 0 ? Math.max(...tickets.map(t => t.number)) + 1 : 101;
        const channelName = `ticket-${ticketNum}`;
        const newChannelId = `c_ticket_${ticketNum}`;

        const newChannel: DiscordChannel = {
          id: newChannelId,
          name: channelName,
          type: 'text',
          categoryId: 'cat_bot',
          topic: `Support ticket #${ticketNum} opened by ${currentUser.username}`,
          isTicket: true,
          ticketId: `t_${ticketNum}`,
        };

        const newTicket: Ticket = {
          id: `t_${ticketNum}`,
          number: ticketNum,
          creatorId: currentUser.id,
          creatorName: currentUser.username,
          channelId: newChannelId,
          status: 'OPEN',
          createdAt: getFormattedTime(),
          topic,
        };

        setChannels(prev => [...prev, newChannel]);
        setTickets(prev => [newTicket, ...prev]);
        setActiveChannelId(newChannelId);

        addBotMessage(
          newChannelId,
          `Hello <@${currentUser.id}>! Staff has been alerted to your inquiry.`,
          [
            {
              title: `🎫 Ticket #${ticketNum} — ${topic}`,
              description: 'Thank you for reaching out to the Aegis Support Team. A moderator or staff member will assist you shortly. Please describe your request in detail below.',
              color: '#5865F2',
              fields: [
                { name: 'Opened By', value: `<@${currentUser.id}>`, inline: true },
                { name: 'Status', value: '`OPEN`', inline: true },
                { name: 'Topic', value: topic, inline: false },
              ],
              footer: { text: 'Click Close Ticket below when resolved' },
            },
          ],
          [
            {
              components: [
                { type: 'button', id: 'btn_close_ticket', label: 'Close Ticket', style: 'DANGER', emoji: '🔒' },
                { type: 'button', id: 'btn_claim_ticket', label: 'Claim Ticket (Staff)', style: 'SUCCESS', emoji: '✋' },
              ],
            },
          ],
          300
        );
        return true;
      }

      case 'close': {
        const currentChannel = channels.find(c => c.id === channelId);
        if (!currentChannel?.isTicket) {
          addBotMessage(channelId, '⚠️ This command can only be run inside an active ticket channel!');
          return true;
        }

        addBotMessage(channelId, '🔒 Ticket is closing and transcript is being generated in 3 seconds...');
        setTimeout(() => {
          setChannels(prev => prev.filter(c => c.id !== channelId));
          setActiveChannelId('c_general');
        }, 3000);
        return true;
      }

      case 'remind': {
        const timeArg = args[0] || '1m';
        const messageArg = args.slice(1).join(' ') || 'Check server status';
        addBotMessage(channelId, `⏰ Got it! I will remind you: **"${messageArg}"** in **${timeArg}**.`);
        return true;
      }

      case 'calc': {
        const expr = args.join(' ');
        try {
          // safe arithmetic evaluation
          const sanitized = expr.replace(/[^0-9+\-*/().]/g, '');
          // eslint-disable-next-line no-eval
          const result = Function(`'use strict'; return (${sanitized})`)();
          addBotMessage(channelId, `🧮 Result: \`${expr}\` = **${result}**`);
        } catch {
          addBotMessage(channelId, `⚠️ Could not compute expression \`${expr}\`. Please check your arithmetic operators.`);
        }
        return true;
      }

      default:
        addBotMessage(channelId, `❓ Unknown command: \`/${cmd}\`. Type \`/help\` to view all 25+ available commands.`);
        return true;
    }
  };

  // Dispatch standard message & run AutoMod / Leveling
  const sendMessage = (content: string, options?: { channelId?: string }) => {
    const targetChannelId = options?.channelId || activeChannelId;
    const author = currentUser;
    const trimmed = content.trim();

    if (!trimmed) return;

    // 1. Check if user typed slash command or prefix command
    if (trimmed.startsWith('/') || trimmed.startsWith(botConfig.prefix)) {
      const userMsg: DiscordMessage = {
        id: `msg_usr_${Date.now()}`,
        channelId: targetChannelId,
        author,
        content: trimmed,
        timestamp: getFormattedTime(),
      };
      setMessages(prev => [...prev, userMsg]);

      executeCommand(trimmed, targetChannelId);
      return;
    }

    // 2. AutoMod Checks on regular message
    let shouldBlock = false;
    let blockReason = '';

    // Bad words check
    if (botConfig.automod.enabled && botConfig.automod.badWordsFilter) {
      const lower = trimmed.toLowerCase();
      const matchedWord = botConfig.automod.badWords.find(w => lower.includes(w.toLowerCase()));
      if (matchedWord) {
        shouldBlock = true;
        blockReason = `Prohibited keyword detected (\`${matchedWord}\`)`;
      }
    }

    // Anti-Invite check
    if (botConfig.automod.enabled && botConfig.automod.antiInvite) {
      if (trimmed.includes('discord.gg/') || trimmed.includes('discord.com/invite/')) {
        shouldBlock = true;
        blockReason = 'Discord invite links are not permitted';
      }
    }

    // Caps lock check
    if (botConfig.automod.enabled && botConfig.automod.antiCaps && trimmed.length > 10) {
      const capsCount = trimmed.replace(/[^A-Z]/g, '').length;
      const lettersCount = trimmed.replace(/[^a-zA-Z]/g, '').length;
      if (lettersCount > 0 && (capsCount / lettersCount) * 100 > botConfig.automod.capsThreshold) {
        shouldBlock = true;
        blockReason = 'Excessive capital letters (>70%)';
      }
    }

    if (shouldBlock) {
      // User message is blocked by AutoMod
      const userMsg: DiscordMessage = {
        id: `msg_usr_${Date.now()}`,
        channelId: targetChannelId,
        author,
        content: `*⚠️ [Message deleted by AutoMod: ${blockReason}]*`,
        timestamp: getFormattedTime(),
      };
      setMessages(prev => [...prev, userMsg]);

      // Increase user warning
      setUsers(prev => ({
        ...prev,
        current_user: {
          ...prev.current_user,
          warnings: prev.current_user.warnings + 1,
        },
      }));

      logModAction('WARN', `${author.username}#${author.discriminator}`, author.id, `${botConfig.name} AutoMod`, blockReason);

      addBotMessage(
        targetChannelId,
        '',
        [
          {
            title: '⚠️ AutoMod Rule Triggered',
            description: `<@${author.id}>, your message was removed by the automated filter.\n\n**Reason:** ${blockReason}\n**Current Infractions:** ${currentUser.warnings + 1} / ${botConfig.automod.maxWarningsBeforeMute}`,
            color: '#ED4245',
            footer: { text: 'Automated server defense' },
          },
        ],
        undefined,
        400
      );
      return;
    }

    // 3. Normal Message Send
    const userMsg: DiscordMessage = {
      id: `msg_usr_${Date.now()}`,
      channelId: targetChannelId,
      author,
      content: trimmed,
      timestamp: getFormattedTime(),
    };
    setMessages(prev => [...prev, userMsg]);

    // 4. Custom Triggers Check
    const matchedCustom = botConfig.customCommands.find(c =>
      trimmed.toLowerCase() === c.trigger.toLowerCase() ||
      trimmed.toLowerCase() === `${botConfig.prefix}${c.trigger.toLowerCase()}`
    );

    if (matchedCustom) {
      if (matchedCustom.responseType === 'embed') {
        addBotMessage(targetChannelId, '', [
          {
            title: matchedCustom.embedTitle || `Trigger: ${matchedCustom.trigger}`,
            description: matchedCustom.content,
            color: matchedCustom.embedColor || '#3498DB',
            footer: { text: 'Custom Auto-Responder' },
          },
        ]);
      } else {
        addBotMessage(targetChannelId, matchedCustom.content);
      }
    }

    // 5. Leveling Engine: Award XP
    if (botConfig.leveling.enabled) {
      const earnedXp = Math.floor(Math.random() * (botConfig.leveling.xpPerMessageMax - botConfig.leveling.xpPerMessageMin + 1)) + botConfig.leveling.xpPerMessageMin;
      const newXp = currentUser.xp + earnedXp;
      const targetThreshold = currentUser.level * 250;
      const leveledUp = newXp >= targetThreshold;
      const newLevel = leveledUp ? currentUser.level + 1 : currentUser.level;

      setUsers(prev => ({
        ...prev,
        current_user: {
          ...prev.current_user,
          xp: newXp,
          level: newLevel,
        },
      }));

      if (leveledUp) {
        const announceChannel = botConfig.leveling.channelId || targetChannelId;
        const msg = botConfig.leveling.levelUpMessage
          .replace('{user}', `<@${currentUser.id}>`)
          .replace('{level}', newLevel.toString());

        addBotMessage(
          announceChannel,
          '',
          [
            {
              title: '🎉 Level Up Celebration!',
              description: msg,
              color: '#F1C40F',
              fields: [
                { name: 'New Level', value: `**Level ${newLevel}**`, inline: true },
                { name: 'Rank Standing', value: '#1 in Community', inline: true },
              ],
              footer: { text: 'Keep chatting to earn rewards and special role rewards!' },
            },
          ],
          undefined,
          1000
        );
      }
    }
  };

  // Interactive component buttons
  const handleComponentClick = (componentId: string, messageId: string) => {
    switch (componentId) {
      case 'btn_create_ticket': {
        executeCommand('/ticket General Inquiry', activeChannelId);
        break;
      }
      case 'btn_close_ticket': {
        executeCommand('/close', activeChannelId);
        break;
      }
      case 'btn_claim_ticket': {
        addBotMessage(activeChannelId, `✋ Ticket has been claimed by staff member <@${currentUser.id}>.`);
        break;
      }
      case 'btn_help_all': {
        executeCommand('/help', activeChannelId);
        break;
      }
      case 'btn_check_ping': {
        executeCommand('/ping', activeChannelId);
        break;
      }
      case 'btn_claim_daily': {
        executeCommand('/daily', activeChannelId);
        break;
      }
      case 'btn_help_mod': {
        executeCommand('/help moderation', activeChannelId);
        break;
      }
      case 'btn_help_util': {
        executeCommand('/help utility', activeChannelId);
        break;
      }
      case 'btn_help_econ': {
        executeCommand('/help leveling', activeChannelId);
        break;
      }
      case 'btn_role_gamer': {
        toggleUserRole('usr_owner', 'role_gamer');
        break;
      }
      case 'btn_role_dev': {
        toggleUserRole('usr_owner', 'role_dev');
        break;
      }
      case 'btn_role_notifs': {
        toggleUserRole('usr_owner', 'role_notifs');
        break;
      }
      case 'btn_poll_yes': {
        addBotMessage(activeChannelId, `✅ <@${currentUser.id}> cast their vote for **Yes**!`, undefined, undefined, 200);
        break;
      }
      case 'btn_poll_no': {
        addBotMessage(activeChannelId, `❌ <@${currentUser.id}> cast their vote for **No**!`, undefined, undefined, 200);
        break;
      }
      default:
        break;
    }
  };

  // Toggle user role
  const toggleUserRole = (userId: string, roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    if (!role) return;

    addBotMessage(
      'c_roles',
      `🎭 <@${userId}> toggled the **@${role.name}** role!`,
      undefined,
      undefined,
      300
    );
  };

  // Simulate Member Chat
  const simulateMemberChat = () => {
    const simulatedMembers = [users.sarah, users.pixel, users.echo];
    const randomMember = simulatedMembers[Math.floor(Math.random() * simulatedMembers.length)];

    const promptSamples = [
      'Hey @AegisBot, how do I check my server rank again?',
      'Has anyone tried the new /poll feature? It is really handy for raid voting!',
      'Just claimed my daily coins! Feeling lucky on the coinflip today 🪙',
      'The AutoMod really cut down on spam in general chat, great job!',
      'Testing the /serverinfo command to see how many members joined this week.',
    ];
    const randomContent = promptSamples[Math.floor(Math.random() * promptSamples.length)];

    const simMsg: DiscordMessage = {
      id: `msg_sim_${Date.now()}`,
      channelId: 'c_general',
      author: randomMember,
      content: randomContent,
      timestamp: getFormattedTime(),
    };
    setMessages(prev => [...prev, simMsg]);

    // Bot automated friendly reply if asked
    if (randomContent.includes('how do I check my server rank')) {
      setTimeout(() => {
        addBotMessage('c_general', `Hey <@${randomMember.id}>, simply type \`/rank\` to view your XP progress and level! 📈`);
      }, 900);
    }
  };

  // Simulate Member Join (Welcome Card)
  const simulateMemberJoin = (customName?: string) => {
    const names = ['VortexRider', 'LunaCyber', 'NeonSamurai', 'CosmicCoder', 'BlazeKnight'];
    const chosenName = customName || names[Math.floor(Math.random() * names.length)];
    const newId = `usr_join_${Date.now()}`;
    const targetChannel = botConfig.welcome.channelId || 'c_welcome';

    const welcomeDescription = botConfig.welcome.message
      .replace('{user}', `<@${newId}>`)
      .replace('{server}', 'Aegis Central')
      .replace('{member_count}', '1,421')
      .replace('{user_id}', newId);

    const welcomeMsg: DiscordMessage = {
      id: `msg_join_${Date.now()}`,
      channelId: targetChannel,
      author: {
        ...botUser,
        username: botConfig.name,
      },
      content: `Welcome to the server, <@${newId}>! 🎉`,
      timestamp: getFormattedTime(),
      embeds: [
        {
          title: botConfig.welcome.title,
          description: welcomeDescription,
          color: botConfig.welcome.embedColor,
          fields: [
            { name: '👤 Username', value: `\`${chosenName}#${Math.floor(1000 + Math.random() * 9000)}\``, inline: true },
            { name: '🛡️ Assigned Role', value: '@Community Member', inline: true },
            { name: '📊 Total Members', value: '1,421 members', inline: true },
          ],
          footer: { text: `${botConfig.name} Automated Welcome System` },
        },
      ],
    };

    setMessages(prev => [...prev, welcomeMsg]);
    setActiveChannelId(targetChannel);
  };

  const clearChannelMessages = (channelId: string) => {
    setMessages(prev => prev.filter(m => m.channelId !== channelId));
  };

  const addCustomCommand = (cmd: CustomCommand) => {
    setBotConfig(prev => ({
      ...prev,
      customCommands: [...prev.customCommands, cmd],
    }));
  };

  const removeCustomCommand = (id: string) => {
    setBotConfig(prev => ({
      ...prev,
      customCommands: prev.customCommands.filter(c => c.id !== id),
    }));
  };

  const revokeModCase = (caseId: string) => {
    setModLogs(prev => prev.filter(l => l.id !== caseId));
  };

  // Send live Discord Webhook
  const sendLiveWebhook = async (url: string, content: string, title?: string, color?: string) => {
    if (!url.startsWith('https://discord.com/api/webhooks/')) {
      return { success: false, message: 'Invalid Discord Webhook URL. It must begin with https://discord.com/api/webhooks/' };
    }

    try {
      const payload: any = {
        username: botConfig.name,
        content: content || undefined,
      };

      if (title) {
        payload.embeds = [
          {
            title,
            description: content,
            color: color ? parseInt(color.replace('#', ''), 16) : 0x5865f2,
            footer: { text: `Dispatched from AegisBot Web Studio` },
            timestamp: new Date().toISOString(),
          },
        ];
      }

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        return { success: true, message: 'Message successfully dispatched to your live Discord channel!' };
      } else {
        const errorText = await response.text();
        return { success: false, message: `Discord API returned status ${response.status}: ${errorText}` };
      }
    } catch (err: any) {
      return { success: false, message: `Network request error: ${err.message}` };
    }
  };

  return (
    <BotContext.Provider
      value={{
        botConfig,
        setBotConfig,
        channels,
        activeChannelId,
        setActiveChannelId,
        users,
        currentUser,
        roles,
        messages,
        modLogs,
        tickets,
        isTyping,
        activeView,
        setActiveView,
        sendMessage,
        handleComponentClick,
        simulateMemberChat,
        simulateMemberJoin,
        toggleUserRole,
        clearChannelMessages,
        addCustomCommand,
        removeCustomCommand,
        revokeModCase,
        sendLiveWebhook,
      }}
    >
      {children}
    </BotContext.Provider>
  );
};

export const useBot = () => {
  const context = useContext(BotContext);
  if (!context) throw new Error('useBot must be used within a BotProvider');
  return context;
};
