export interface DiscordUser {
  id: string;
  username: string;
  discriminator: string;
  avatarColor: string;
  avatarIcon?: string;
  isBot?: boolean;
  roleId: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  activity?: string;
  joinedAt: string;
  warnings: number;
  level: number;
  xp: number;
  balance: number;
}

export interface DiscordRole {
  id: string;
  name: string;
  color: string;
  hoist: boolean;
  position: number;
}

export interface DiscordChannel {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'announcement';
  categoryId?: string;
  topic?: string;
  unreadCount?: number;
  isTicket?: boolean;
  ticketId?: string;
}

export interface DiscordCategory {
  id: string;
  name: string;
}

export interface DiscordEmbedField {
  name: string;
  value: string;
  inline?: boolean;
}

export interface DiscordEmbed {
  title?: string;
  description?: string;
  url?: string;
  color?: string; // hex color e.g. #5865F2, #57F287, #ED4245, #FEE75C
  author?: {
    name: string;
    icon_url?: string;
    url?: string;
  };
  fields?: DiscordEmbedField[];
  thumbnail?: {
    url: string;
  };
  image?: {
    url: string;
  };
  footer?: {
    text: string;
    icon_url?: string;
  };
  timestamp?: string;
}

export interface DiscordButton {
  type: 'button';
  id: string;
  label: string;
  style: 'PRIMARY' | 'SECONDARY' | 'SUCCESS' | 'DANGER' | 'LINK';
  emoji?: string;
  url?: string;
  disabled?: boolean;
}

export interface DiscordSelectOption {
  label: string;
  value: string;
  description?: string;
  emoji?: string;
}

export interface DiscordSelectMenu {
  type: 'select';
  id: string;
  placeholder: string;
  options: DiscordSelectOption[];
  disabled?: boolean;
}

export interface DiscordActionRow {
  components: (DiscordButton | DiscordSelectMenu)[];
}

export interface DiscordMessage {
  id: string;
  channelId: string;
  author: DiscordUser;
  content: string;
  timestamp: string;
  embeds?: DiscordEmbed[];
  components?: DiscordActionRow[];
  isPinned?: boolean;
  reactions?: {
    emoji: string;
    count: number;
    users: string[]; // user IDs
  }[];
}

export interface ModLogEntry {
  id: string;
  caseNumber: number;
  action: 'WARN' | 'MUTE' | 'UNMUTE' | 'KICK' | 'BAN' | 'UNBAN' | 'PURGE';
  targetUser: string;
  targetId: string;
  moderator: string;
  reason: string;
  timestamp: string;
}

export interface Ticket {
  id: string;
  number: number;
  creatorId: string;
  creatorName: string;
  channelId: string;
  status: 'OPEN' | 'CLAIMED' | 'CLOSED';
  createdAt: string;
  claimedBy?: string;
  topic: string;
}

export interface SlashCommand {
  name: string;
  description: string;
  category: 'Moderation' | 'Utility' | 'Leveling & Economy' | 'Engagement & Fun' | 'Tickets & Support' | 'Configuration';
  syntax: string;
  example: string;
  userPermissions?: string[];
  options?: {
    name: string;
    description: string;
    required?: boolean;
    type?: string;
  }[];
}

export interface AutoModRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  action: 'WARN' | 'DELETE' | 'MUTE';
}

export interface ReactionRoleConfig {
  id: string;
  channelId: string;
  title: string;
  description: string;
  roles: {
    roleId: string;
    roleName: string;
    emoji: string;
    color: string;
  }[];
}

export interface CustomCommand {
  id: string;
  trigger: string;
  responseType: 'text' | 'embed';
  content: string;
  embedTitle?: string;
  embedColor?: string;
  authorOnly?: boolean;
}

export interface BotConfig {
  name: string;
  discriminator: string;
  prefix: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  activityType: 'PLAYING' | 'LISTENING' | 'WATCHING' | 'STREAMING' | 'COMPETING';
  activityName: string;
  themeColor: string;
  automod: {
    enabled: boolean;
    antiInvite: boolean;
    antiLinks: boolean;
    antiCaps: boolean;
    capsThreshold: number; // e.g. 70%
    badWordsFilter: boolean;
    badWords: string[];
    antiSpam: boolean;
    maxWarningsBeforeMute: number;
    maxWarningsBeforeBan: number;
  };
  welcome: {
    enabled: boolean;
    channelId: string;
    title: string;
    message: string;
    embedColor: string;
    sendDM: boolean;
    autoRoleId?: string;
  };
  leveling: {
    enabled: boolean;
    xpPerMessageMin: number;
    xpPerMessageMax: number;
    cooldownSeconds: number;
    channelId: string; // empty = current channel
    levelUpMessage: string;
  };
  economy: {
    enabled: boolean;
    currencySymbol: string;
    dailyAmount: number;
    startingBalance: number;
  };
  tickets: {
    enabled: boolean;
    channelId: string;
    panelTitle: string;
    panelDescription: string;
    buttonLabel: string;
    buttonColor: 'PRIMARY' | 'SECONDARY' | 'SUCCESS' | 'DANGER';
  };
  reactionRoles: ReactionRoleConfig[];
  customCommands: CustomCommand[];
}
