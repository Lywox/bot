import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import {
  Sliders,
  Shield,
  PartyPopper,
  Coins,
  Ticket as TicketIcon,
  MessageSquareCode,
  Check,
  Plus,
  Trash2,
  ExternalLink,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { CustomCommand } from '../../types/discord.ts';

type DashboardTab = 'general' | 'automod' | 'welcome' | 'leveling' | 'tickets' | 'custom';

export const BotDashboard: React.FC = () => {
  const {
    botConfig,
    setBotConfig,
    channels,
    roles,
    modLogs,
    revokeModCase,
    simulateMemberJoin,
    setActiveChannelId,
    setActiveView,
    tickets,
    addCustomCommand,
    removeCustomCommand,
    users
  } = useBot();

  const [activeTab, setActiveTab] = useState<DashboardTab>('general');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // New custom command form state
  const [newTrigger, setNewTrigger] = useState('');
  const [newResponse, setNewResponse] = useState('');
  const [newResponseType, setNewResponseType] = useState<'text' | 'embed'>('text');
  const [newEmbedTitle, setNewEmbedTitle] = useState('');

  // Bad words input state
  const [newBadWord, setNewBadWord] = useState('');

  const triggerSaveNotification = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleAddBadWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBadWord.trim()) return;
    const word = newBadWord.trim().toLowerCase();
    if (!botConfig.automod.badWords.includes(word)) {
      setBotConfig(prev => ({
        ...prev,
        automod: {
          ...prev.automod,
          badWords: [...prev.automod.badWords, word],
        },
      }));
      setNewBadWord('');
      triggerSaveNotification();
    }
  };

  const handleRemoveBadWord = (word: string) => {
    setBotConfig(prev => ({
      ...prev,
      automod: {
        ...prev.automod,
        badWords: prev.automod.badWords.filter(w => w !== word),
      },
    }));
    triggerSaveNotification();
  };

  const handleCreateCustomCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrigger.trim() || !newResponse.trim()) return;

    const cmd: CustomCommand = {
      id: `cmd_${Date.now()}`,
      trigger: newTrigger.trim().replace(/^!/, ''),
      responseType: newResponseType,
      content: newResponse.trim(),
      embedTitle: newResponseType === 'embed' ? newEmbedTitle.trim() || undefined : undefined,
      embedColor: '#5865F2',
    };

    addCustomCommand(cmd);
    setNewTrigger('');
    setNewResponse('');
    setNewEmbedTitle('');
    triggerSaveNotification();
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-[#1e1f22] h-[calc(100vh-61px)]">
      {/* Left Settings Sidebar */}
      <div className="w-64 bg-[#2b2d31] border-r border-[#232428] flex flex-col p-3 shrink-0 select-none">
        <div className="px-3 py-2 text-xs font-bold text-[#949ba4] uppercase tracking-wider">
          Bot Modules & Config
        </div>

        <div className="space-y-1 mt-1">
          {[
            { id: 'general', label: 'Identity & Status', icon: Sliders },
            { id: 'automod', label: 'AutoMod & Moderation', icon: Shield },
            { id: 'welcome', label: 'Welcome & Greetings', icon: PartyPopper },
            { id: 'leveling', label: 'Leveling & Economy', icon: Coins },
            { id: 'tickets', label: 'Support & Tickets', icon: TicketIcon },
            { id: 'custom', label: 'Custom Auto-Responders', icon: MessageSquareCode },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as DashboardTab)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold transition-colors text-left ${
                  isActive
                    ? 'bg-[#5865F2] text-white shadow-sm'
                    : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Live Status Summary Card */}
        <div className="mt-auto bg-[#1e1f22] border border-[#35373c] rounded-xl p-3.5 space-y-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#23a55a] animate-pulse" />
            <span className="text-xs font-bold text-white">Bot Gateway Active</span>
          </div>
          <div className="text-[11px] text-[#949ba4] space-y-1">
            <div className="flex justify-between">
              <span>Prefix:</span>
              <span className="font-mono text-white font-semibold">{botConfig.prefix}</span>
            </div>
            <div className="flex justify-between">
              <span>AutoMod:</span>
              <span className={botConfig.automod.enabled ? 'text-[#23a55a] font-semibold' : 'text-[#f23f43]'}>
                {botConfig.automod.enabled ? 'Enforced' : 'Disabled'}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Active Cases:</span>
              <span className="font-semibold text-white">{modLogs.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Settings Panel */}
      <div className="flex-1 overflow-y-auto p-6 lg:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#2b2d31] pb-4">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              {activeTab === 'general' && 'General Identity & Presence'}
              {activeTab === 'automod' && 'AutoMod & Moderation Enforcement'}
              {activeTab === 'welcome' && 'Welcome Card & Member Onboarding'}
              {activeTab === 'leveling' && 'Leveling, Experience & Economy'}
              {activeTab === 'tickets' && 'Support Desk & Ticket Workflow'}
              {activeTab === 'custom' && 'Custom Auto-Responders & Commands'}
            </h1>
            <p className="text-xs text-[#949ba4] mt-1">
              Changes applied here instantly reflect inside the simulated Discord guild canvas.
            </p>
          </div>

          {saveSuccess && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#23a55a]/20 border border-[#23a55a]/40 text-[#23a55a] text-xs font-semibold rounded-lg animate-fade-in">
              <Check className="w-3.5 h-3.5" />
              <span>Configuration Saved</span>
            </div>
          )}
        </div>

        {/* TAB 1: GENERAL IDENTITY */}
        {activeTab === 'general' && (
          <div className="space-y-6 max-w-3xl">
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Bot Identity Profile
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Bot Display Name
                  </label>
                  <input
                    type="text"
                    value={botConfig.name}
                    onChange={e => {
                      setBotConfig(prev => ({ ...prev, name: e.target.value }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Command Prefix
                  </label>
                  <input
                    type="text"
                    value={botConfig.prefix}
                    maxLength={3}
                    onChange={e => {
                      setBotConfig(prev => ({ ...prev, prefix: e.target.value }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#5865F2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Rich Presence Activity Type
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['PLAYING', 'LISTENING', 'WATCHING', 'COMPETING'] as const).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => {
                        setBotConfig(prev => ({ ...prev, activityType: type }));
                        triggerSaveNotification();
                      }}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors capitalize ${
                        botConfig.activityType === type
                          ? 'bg-[#5865F2] text-white shadow-sm'
                          : 'bg-[#1e1f22] text-[#949ba4] hover:bg-[#35373c] hover:text-white border border-[#3b3e45]'
                      }`}
                    >
                      {type.toLowerCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Custom Status Text
                </label>
                <input
                  type="text"
                  value={botConfig.activityName}
                  onChange={e => {
                    setBotConfig(prev => ({ ...prev, activityName: e.target.value }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                  placeholder="/help | Protecting 1,420 members"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Online Status State
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'online', label: 'Online (Green)', color: 'bg-[#23a55a]' },
                    { id: 'idle', label: 'Idle (Amber)', color: 'bg-[#f0b232]' },
                    { id: 'dnd', label: 'Do Not Disturb (Red)', color: 'bg-[#f23f43]' },
                  ].map(st => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => {
                        setBotConfig(prev => ({ ...prev, status: st.id as any }));
                        triggerSaveNotification();
                      }}
                      className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold border transition-colors ${
                        botConfig.status === st.id
                          ? 'bg-[#1e1f22] text-white border-[#5865F2]'
                          : 'bg-[#1e1f22] text-[#949ba4] border-[#3b3e45] hover:text-white'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${st.color}`} />
                      <span>{st.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AUTOMOD & MODERATION */}
        {activeTab === 'automod' && (
          <div className="space-y-6 max-w-4xl">
            {/* Rules Toggles */}
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Automated Moderation Engine
                  </h2>
                  <p className="text-xs text-[#949ba4]">
                    Intercept harmful messages in real-time before other members see them.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={botConfig.automod.enabled}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        automod: { ...prev.automod, enabled: e.target.checked },
                      }));
                      triggerSaveNotification();
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-[#3f4147] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5865F2]" />
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Block Discord Invites</div>
                    <div className="text-[11px] text-[#949ba4]">Deletes links like discord.gg/*</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={botConfig.automod.antiInvite}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        automod: { ...prev.automod, antiInvite: e.target.checked },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-4 h-4 text-[#5865F2] rounded focus:ring-0 cursor-pointer"
                  />
                </div>

                <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Excessive Caps Lock Filter</div>
                    <div className="text-[11px] text-[#949ba4]">Warns if caps exceed threshold</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={botConfig.automod.antiCaps}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        automod: { ...prev.automod, antiCaps: e.target.checked },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-4 h-4 text-[#5865F2] rounded focus:ring-0 cursor-pointer"
                  />
                </div>

                <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Bad Terminology Filter</div>
                    <div className="text-[11px] text-[#949ba4]">Scans for blacklist keywords</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={botConfig.automod.badWordsFilter}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        automod: { ...prev.automod, badWordsFilter: e.target.checked },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-4 h-4 text-[#5865F2] rounded focus:ring-0 cursor-pointer"
                  />
                </div>

                <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Anti-Spam Flooding</div>
                    <div className="text-[11px] text-[#949ba4]">Rate limits message bursts</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={botConfig.automod.antiSpam}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        automod: { ...prev.automod, antiSpam: e.target.checked },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-4 h-4 text-[#5865F2] rounded focus:ring-0 cursor-pointer"
                  />
                </div>
              </div>

              {/* Bad Words Blacklist Editor */}
              <div className="pt-2 border-t border-[#3b3e45]/50 space-y-2">
                <label className="block text-xs font-semibold text-[#b5bac1]">
                  Prohibited Keywords Blacklist ({botConfig.automod.badWords.length})
                </label>

                <div className="flex flex-wrap gap-1.5 p-2.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] min-h-[46px]">
                  {botConfig.automod.badWords.map(word => (
                    <span
                      key={word}
                      className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#35373c] text-white text-xs rounded-md"
                    >
                      <span className="font-mono">{word}</span>
                      <button
                        onClick={() => handleRemoveBadWord(word)}
                        className="text-[#949ba4] hover:text-[#ED4245]"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>

                <form onSubmit={handleAddBadWord} className="flex gap-2">
                  <input
                    type="text"
                    value={newBadWord}
                    onChange={e => setNewBadWord(e.target.value)}
                    placeholder="Add term (e.g. scam, free-nitro)..."
                    className="flex-1 bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#5865F2]"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-[#35373c] hover:bg-[#5865F2] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Moderation Logs Table */}
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Audit Log & Enforcement History
                  </h2>
                  <p className="text-xs text-[#949ba4]">
                    Recorded moderation cases and actions taken by AegisBot or server staff.
                  </p>
                </div>
              </div>

              {modLogs.length === 0 ? (
                <div className="text-center py-8 text-xs text-[#949ba4]">
                  No moderation cases recorded yet. Run `/warn` or `/mute` in the simulator.
                </div>
              ) : (
                <div className="overflow-x-auto border border-[#3b3e45] rounded-lg">
                  <table className="w-full text-left text-xs text-[#dbdee1]">
                    <thead className="bg-[#1e1f22] text-[#949ba4] border-b border-[#3b3e45] uppercase font-bold text-[10px] tracking-wider">
                      <tr>
                        <th className="py-2.5 px-3">Case</th>
                        <th className="py-2.5 px-3">Action</th>
                        <th className="py-2.5 px-3">Target</th>
                        <th className="py-2.5 px-3">Moderator</th>
                        <th className="py-2.5 px-3">Reason</th>
                        <th className="py-2.5 px-3">Time</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#35373c]">
                      {modLogs.map(log => (
                        <tr key={log.id} className="hover:bg-[#35373c]/40 transition-colors">
                          <td className="py-2.5 px-3 font-mono font-semibold text-white">
                            #{log.caseNumber}
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                log.action === 'BAN' || log.action === 'KICK'
                                  ? 'bg-[#ED4245]/20 text-[#ED4245]'
                                  : log.action === 'MUTE'
                                  ? 'bg-[#E67E22]/20 text-[#E67E22]'
                                  : log.action === 'WARN'
                                  ? 'bg-[#FEE75C]/20 text-[#FEE75C]'
                                  : 'bg-[#5865F2]/20 text-[#5865F2]'
                              }`}
                            >
                              {log.action}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 font-medium text-white">{log.targetUser}</td>
                          <td className="py-2.5 px-3 text-[#949ba4]">{log.moderator}</td>
                          <td className="py-2.5 px-3 max-w-xs truncate">{log.reason}</td>
                          <td className="py-2.5 px-3 text-[#949ba4]">{log.timestamp}</td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={() => revokeModCase(log.id)}
                              className="text-[11px] text-[#ED4245] hover:underline"
                            >
                              Revoke
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: WELCOME & GREETINGS */}
        {activeTab === 'welcome' && (
          <div className="space-y-6 max-w-3xl">
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Member Welcome System
                  </h2>
                  <p className="text-xs text-[#949ba4]">
                    Sends an attractive greeting card embed when new members join.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    simulateMemberJoin();
                    setActiveView('simulator');
                  }}
                  className="px-3 py-1.5 bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <PartyPopper className="w-3.5 h-3.5" />
                  <span>Test Welcome Card</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Announcement Channel
                  </label>
                  <select
                    value={botConfig.welcome.channelId}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        welcome: { ...prev.welcome, channelId: e.target.value },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                  >
                    {channels.filter(c => c.type === 'text').map(c => (
                      <option key={c.id} value={c.id}>
                        #{c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Auto-Assign Role on Join
                  </label>
                  <select
                    value={botConfig.welcome.autoRoleId || ''}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        welcome: { ...prev.welcome, autoRoleId: e.target.value },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                  >
                    <option value="">No Auto-Role</option>
                    {roles.map(r => (
                      <option key={r.id} value={r.id}>
                        @{r.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Card Embed Title
                </label>
                <input
                  type="text"
                  value={botConfig.welcome.title}
                  onChange={e => {
                    setBotConfig(prev => ({
                      ...prev,
                      welcome: { ...prev.welcome, title: e.target.value },
                    }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Welcome Message Body
                </label>
                <textarea
                  rows={3}
                  value={botConfig.welcome.message}
                  onChange={e => {
                    setBotConfig(prev => ({
                      ...prev,
                      welcome: { ...prev.welcome, message: e.target.value },
                    }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg p-3 text-xs text-white focus:outline-none focus:border-[#5865F2]"
                />
                <div className="flex items-center gap-2 mt-1.5 text-[11px] text-[#949ba4]">
                  <span>Variables:</span>
                  <span className="font-mono bg-[#1e1f22] px-1.5 py-0.5 rounded text-white">{'{user}'}</span>
                  <span className="font-mono bg-[#1e1f22] px-1.5 py-0.5 rounded text-white">{'{server}'}</span>
                  <span className="font-mono bg-[#1e1f22] px-1.5 py-0.5 rounded text-white">{'{member_count}'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: LEVELING & ECONOMY */}
        {activeTab === 'leveling' && (
          <div className="space-y-6 max-w-4xl">
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Leveling & XP Engine Settings
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Min XP per message
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={botConfig.leveling.xpPerMessageMin}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        leveling: { ...prev.leveling, xpPerMessageMin: parseInt(e.target.value, 10) || 15 },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#5865F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Max XP per message
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={100}
                    value={botConfig.leveling.xpPerMessageMax}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        leveling: { ...prev.leveling, xpPerMessageMax: parseInt(e.target.value, 10) || 25 },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#5865F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Daily Allowance Coins
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={1000}
                    value={botConfig.economy.dailyAmount}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        economy: { ...prev.economy, dailyAmount: parseInt(e.target.value, 10) || 150 },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#5865F2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Level Up Announcement Template
                </label>
                <input
                  type="text"
                  value={botConfig.leveling.levelUpMessage}
                  onChange={e => {
                    setBotConfig(prev => ({
                      ...prev,
                      leveling: { ...prev.leveling, levelUpMessage: e.target.value },
                    }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>
            </div>

            {/* Current Top Standings */}
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Live Server XP Leaderboard
              </h2>

              <div className="divide-y divide-[#35373c] border border-[#3b3e45] rounded-lg overflow-hidden">
                {Object.values(users)
                  .filter(u => !u.isBot)
                  .sort((a, b) => b.xp - a.xp)
                  .map((u, i) => (
                    <div key={u.id} className="flex items-center justify-between p-3 bg-[#1e1f22] text-xs">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-white w-6 text-center">
                          {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
                        </span>
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center font-bold text-white text-xs"
                          style={{ backgroundColor: u.avatarColor }}
                        >
                          {u.username.slice(0, 2).toUpperCase()}
                        </div>
                        <span className="font-semibold text-white">{u.username}</span>
                      </div>

                      <div className="flex items-center gap-4 text-[#949ba4]">
                        <span>Level <strong className="text-white">{u.level}</strong></span>
                        <span className="font-mono text-white">{u.xp.toLocaleString()} XP</span>
                        <span className="text-[#FEE75C] font-semibold">🪙 {u.balance}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: TICKETS */}
        {activeTab === 'tickets' && (
          <div className="space-y-6 max-w-3xl">
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Ticket Desk Configuration
              </h2>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Ticket Panel Title
                </label>
                <input
                  type="text"
                  value={botConfig.tickets.panelTitle}
                  onChange={e => {
                    setBotConfig(prev => ({
                      ...prev,
                      tickets: { ...prev.tickets, panelTitle: e.target.value },
                    }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                  Panel Description
                </label>
                <textarea
                  rows={3}
                  value={botConfig.tickets.panelDescription}
                  onChange={e => {
                    setBotConfig(prev => ({
                      ...prev,
                      tickets: { ...prev.tickets, panelDescription: e.target.value },
                    }));
                    triggerSaveNotification();
                  }}
                  className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg p-3 text-xs text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Button Label
                  </label>
                  <input
                    type="text"
                    value={botConfig.tickets.buttonLabel}
                    onChange={e => {
                      setBotConfig(prev => ({
                        ...prev,
                        tickets: { ...prev.tickets, buttonLabel: e.target.value },
                      }));
                      triggerSaveNotification();
                    }}
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Active Open Tickets
                  </label>
                  <div className="bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono">
                    {tickets.filter(t => t.status === 'OPEN').length} Tickets Open
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CUSTOM COMMANDS */}
        {activeTab === 'custom' && (
          <div className="space-y-6 max-w-3xl">
            {/* Create New Trigger */}
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Create Custom Trigger / Auto-Responder
              </h2>

              <form onSubmit={handleCreateCustomCommand} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                      Trigger Phrase / Command
                    </label>
                    <input
                      type="text"
                      value={newTrigger}
                      onChange={e => setNewTrigger(e.target.value)}
                      placeholder="e.g. faq or rules"
                      className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                      Response Style
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setNewResponseType('text')}
                        className={`px-3 py-2 rounded-lg text-xs font-semibold ${
                          newResponseType === 'text'
                            ? 'bg-[#5865F2] text-white'
                            : 'bg-[#1e1f22] text-[#949ba4] border border-[#3b3e45]'
                        }`}
                      >
                        Plain Text
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewResponseType('embed')}
                        className={`px-3 py-2 rounded-lg text-xs font-semibold ${
                          newResponseType === 'embed'
                            ? 'bg-[#5865F2] text-white'
                            : 'bg-[#1e1f22] text-[#949ba4] border border-[#3b3e45]'
                        }`}
                      >
                        Rich Embed
                      </button>
                    </div>
                  </div>
                </div>

                {newResponseType === 'embed' && (
                  <div>
                    <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                      Embed Title
                    </label>
                    <input
                      type="text"
                      value={newEmbedTitle}
                      onChange={e => setNewEmbedTitle(e.target.value)}
                      placeholder="e.g. Frequently Asked Questions"
                      className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                    Bot Response Content
                  </label>
                  <textarea
                    rows={3}
                    value={newResponse}
                    onChange={e => setNewResponse(e.target.value)}
                    placeholder="Enter what the bot should say..."
                    className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg p-3 text-xs text-white focus:outline-none focus:border-[#5865F2]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!newTrigger.trim() || !newResponse.trim()}
                  className="px-4 py-2 bg-[#5865F2] hover:bg-[#4752c4] disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Register Auto-Responder</span>
                </button>
              </form>
            </div>

            {/* Existing Custom Commands */}
            <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Configured Auto-Responders ({botConfig.customCommands.length})
              </h2>

              <div className="space-y-2">
                {botConfig.customCommands.map(cmd => (
                  <div
                    key={cmd.id}
                    className="p-3 bg-[#1e1f22] border border-[#3b3e45] rounded-lg flex items-start justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#5865F2]">!{cmd.trigger}</span>
                        <span className="text-[10px] bg-[#35373c] text-[#b5bac1] px-1.5 py-0.5 rounded uppercase">
                          {cmd.responseType}
                        </span>
                      </div>
                      {cmd.embedTitle && (
                        <div className="font-semibold text-white mt-1">{cmd.embedTitle}</div>
                      )}
                      <div className="text-[#949ba4] mt-0.5 max-w-lg whitespace-pre-line">
                        {cmd.content}
                      </div>
                    </div>

                    <button
                      onClick={() => removeCustomCommand(cmd.id)}
                      className="p-1.5 text-[#949ba4] hover:text-[#ED4245] transition-colors"
                      title="Delete Command"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
