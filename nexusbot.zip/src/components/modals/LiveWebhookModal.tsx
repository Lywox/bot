import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { X, Send, CheckCircle2, AlertCircle, Sparkles, ExternalLink } from 'lucide-react';

interface LiveWebhookModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveWebhookModal: React.FC<LiveWebhookModalProps> = ({ isOpen, onClose }) => {
  const { sendLiveWebhook, botConfig } = useBot();
  const [webhookUrl, setWebhookUrl] = useState('');
  const [messageText, setMessageText] = useState('Greetings from AegisBot Web Studio! Your bot integration is functional.');
  const [embedTitle, setEmbedTitle] = useState('🛡️ AegisBot Test Transmission');
  const [embedColor, setEmbedColor] = useState('#5865F2');
  const [isSending, setIsSending] = useState(false);
  const [statusResult, setStatusResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!webhookUrl.trim() || !messageText.trim()) return;

    setIsSending(true);
    setStatusResult(null);

    const result = await sendLiveWebhook(webhookUrl.trim(), messageText.trim(), embedTitle.trim(), embedColor);
    setIsSending(false);
    setStatusResult(result);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="p-4 px-6 bg-[#1e1f22] border-b border-[#3b3e45] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-[#5865F2]" />
            <h3 className="font-bold text-white text-sm">Send Live Webhook to Real Discord Server</h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#949ba4] hover:text-white p-1 rounded hover:bg-[#35373c] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Content */}
        <form onSubmit={handleSend} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-[#b5bac1] mb-1">
              Discord Webhook URL
            </label>
            <input
              type="url"
              value={webhookUrl}
              onChange={e => setWebhookUrl(e.target.value)}
              placeholder="https://discord.com/api/webhooks/..."
              className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-white font-mono placeholder-[#72767d] focus:outline-none focus:border-[#5865F2]"
              required
            />
            <p className="text-[10px] text-[#949ba4] mt-1">
              In your Discord server: Channel Settings → Integrations → Webhooks → New Webhook → Copy URL.
            </p>
          </div>

          <div>
            <label className="block font-semibold text-[#b5bac1] mb-1">
              Embed Title (Optional)
            </label>
            <input
              type="text"
              value={embedTitle}
              onChange={e => setEmbedTitle(e.target.value)}
              className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#5865F2]"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#b5bac1] mb-1">
              Message Content / Description
            </label>
            <textarea
              rows={3}
              value={messageText}
              onChange={e => setMessageText(e.target.value)}
              className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg p-3 text-white focus:outline-none focus:border-[#5865F2]"
              required
            />
          </div>

          {statusResult && (
            <div
              className={`p-3 rounded-lg border flex items-start gap-2 ${
                statusResult.success
                  ? 'bg-[#23a55a]/10 border-[#23a55a]/30 text-[#23a55a]'
                  : 'bg-[#f23f43]/10 border-[#f23f43]/30 text-[#f23f43]'
              }`}
            >
              {statusResult.success ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              )}
              <span className="leading-tight">{statusResult.message}</span>
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-[#3b3e45]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#35373c] hover:bg-[#404249] text-white rounded-lg font-semibold transition-colors"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isSending || !webhookUrl.trim()}
              className="px-4 py-2 bg-[#5865F2] hover:bg-[#4752c4] disabled:opacity-50 text-white rounded-lg font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSending ? 'Sending...' : 'Send Live Message'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
