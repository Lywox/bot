import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { Bot, Terminal, Sliders, BookOpen, Code2, Sparkles, Send, Check, FolderArchive } from 'lucide-react';
import JSZip from 'jszip';
import {
  generateDeployCommandsTs,
  generateEnvExample,
  generateIndexTs,
  generatePackageJson,
  generatePythonBot,
  generateReadme,
  generateTsConfig,
} from '../../utils/codeTemplates.ts';

interface TopBarProps {
  onOpenWebhookModal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenWebhookModal }) => {
  const { activeView, setActiveView, botConfig, simulateMemberChat, simulateMemberJoin } = useBot();
  const [copiedLink, setCopiedLink] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopyInvite = () => {
    const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=123456789012345678&permissions=8&scope=bot%20applications.commands`;
    navigator.clipboard?.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleQuickDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();
      const folderName = `${botConfig.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-bot`;
      const root = zip.folder(folderName) || zip;

      root.file('package.json', generatePackageJson(botConfig));
      root.file('tsconfig.json', generateTsConfig());
      root.file('.env.example', generateEnvExample());
      root.file('.env', generateEnvExample());
      root.file('README.md', generateReadme(botConfig));
      root.file('bot.py', generatePythonBot(botConfig));

      const srcFolder = root.folder('src');
      if (srcFolder) {
        srcFolder.file('index.ts', generateIndexTs(botConfig));
        srcFolder.file('deploy-commands.ts', generateDeployCommandsTs(botConfig));
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${folderName}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <header className="flex items-center justify-between px-6 py-3.5 bg-[#1e1f22] border-b border-[#2b2d31] shrink-0 z-30 select-none">
      {/* Zone 1: Brand Zone - Single text element wordmark */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center text-white shadow-sm shadow-[#5865F2]/20">
          <Bot className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
            {botConfig.name}
            <span className="text-[10px] font-semibold bg-[#5865F2] text-white px-1.5 py-0.2 rounded text-center tracking-normal">
              APP
            </span>
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links (single-line, clean text links) */}
      <nav className="hidden md:flex items-center gap-1 bg-[#2b2d31]/60 p-1 rounded-lg border border-[#35373c]">
        <button
          onClick={() => setActiveView('simulator')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeView === 'simulator'
              ? 'bg-[#5865F2] text-white shadow-sm'
              : 'text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]/50'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          Guild Simulator
        </button>

        <button
          onClick={() => setActiveView('dashboard')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeView === 'dashboard'
              ? 'bg-[#5865F2] text-white shadow-sm'
              : 'text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]/50'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          Bot Dashboard
        </button>

        <button
          onClick={() => setActiveView('commands')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeView === 'commands'
              ? 'bg-[#5865F2] text-white shadow-sm'
              : 'text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]/50'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Commands Library
        </button>

        <button
          onClick={() => setActiveView('exporter')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeView === 'exporter'
              ? 'bg-[#5865F2] text-white shadow-sm'
              : 'text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]/50'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          Code Exporter
        </button>

        <button
          onClick={() => setActiveView('developer-guide')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeView === 'developer-guide'
              ? 'bg-[#5865F2] text-white shadow-sm'
              : 'text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]/50'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Discord Setup Guide
        </button>
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2.5">
        {activeView === 'simulator' && (
          <div className="hidden lg:flex items-center gap-1.5 mr-1">
            <button
              onClick={simulateMemberChat}
              title="Simulate random member chatting in #general"
              className="px-2.5 py-1.5 text-xs font-medium text-[#dbdee1] bg-[#2b2d31] hover:bg-[#35373c] border border-[#3b3e45] rounded-md transition-colors whitespace-nowrap"
            >
              Simulate Chat
            </button>
            <button
              onClick={() => simulateMemberJoin()}
              title="Simulate a new member joining (triggers welcome card)"
              className="px-2.5 py-1.5 text-xs font-medium text-[#dbdee1] bg-[#2b2d31] hover:bg-[#35373c] border border-[#3b3e45] rounded-md transition-colors whitespace-nowrap"
            >
              Simulate Join
            </button>
          </div>
        )}

        <button
          onClick={onOpenWebhookModal}
          className="px-3 py-1.5 text-xs font-medium text-[#dbdee1] bg-[#2b2d31] hover:bg-[#35373c] border border-[#3b3e45] rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
        >
          <Send className="w-3.5 h-3.5 text-[#5865F2]" />
          <span>Live Webhook</span>
        </button>

        <button
          onClick={handleQuickDownloadZip}
          disabled={isZipping}
          className="px-3 py-1.5 text-xs font-semibold text-white bg-[#23a55a] hover:bg-[#1a7f45] active:bg-[#156738] rounded-md transition-colors flex items-center gap-1.5 shadow-sm whitespace-nowrap cursor-pointer"
          title="Download ready-to-run Discord bot project as ZIP"
        >
          {isZipping ? (
            <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <FolderArchive className="w-3.5 h-3.5" />
          )}
          <span>Download ZIP</span>
        </button>

        <button
          onClick={handleCopyInvite}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#5865F2] hover:bg-[#4752c4] active:bg-[#3c45a5] rounded-md transition-colors flex items-center gap-1.5 shadow-sm whitespace-nowrap"
        >
          {copiedLink ? (
            <>
              <Check className="w-3.5 h-3.5 text-[#57F287]" />
              <span>Link Copied!</span>
            </>
          ) : (
            <>
              <Bot className="w-3.5 h-3.5" />
              <span>Invite Bot</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
