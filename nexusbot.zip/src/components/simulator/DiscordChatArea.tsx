import React, { useState, useRef, useEffect } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { ALL_SLASH_COMMANDS } from '../../data/defaultData.ts';
import { DiscordEmbed, DiscordMessage, SlashCommand } from '../../types/discord.ts';
import {
  Hash,
  Bell,
  Pin,
  Users,
  Search,
  PlusCircle,
  Smile,
  Send,
  Sparkles,
  Command,
  Trash2,
  Lock,
  Megaphone,
  CheckCircle2
} from 'lucide-react';

interface DiscordChatAreaProps {
  showMemberList: boolean;
  setShowMemberList: React.Dispatch<React.SetStateAction<boolean>>;
}

export const DiscordChatArea: React.FC<DiscordChatAreaProps> = ({
  showMemberList,
  setShowMemberList,
}) => {
  const {
    channels,
    activeChannelId,
    messages,
    sendMessage,
    handleComponentClick,
    isTyping,
    botConfig,
    roles,
    clearChannelMessages,
  } = useBot();

  const [inputVal, setInputVal] = useState('');
  const [slashPopoverOpen, setSlashPopoverOpen] = useState(false);
  const [selectedSlashIndex, setSelectedSlashIndex] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentChannel = channels.find(c => c.id === activeChannelId) || channels[0];
  const channelMessages = messages.filter(m => m.channelId === activeChannelId);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMessages, isTyping]);

  // Autocomplete filtering for slash commands
  const filteredCommands = inputVal.startsWith('/')
    ? ALL_SLASH_COMMANDS.filter(cmd =>
        cmd.name.toLowerCase().includes(inputVal.slice(1).toLowerCase().split(' ')[0])
      )
    : [];

  useEffect(() => {
    if (inputVal.startsWith('/') && filteredCommands.length > 0) {
      setSlashPopoverOpen(true);
    } else {
      setSlashPopoverOpen(false);
    }
    setSelectedSlashIndex(0);
  }, [inputVal]);

  const handleFormSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputVal.trim()) return;

    sendMessage(inputVal);
    setInputVal('');
    setSlashPopoverOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (slashPopoverOpen && filteredCommands.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedSlashIndex(prev => (prev + 1) % filteredCommands.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedSlashIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
      } else if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        const chosen = filteredCommands[selectedSlashIndex];
        setInputVal(`/${chosen.name} `);
        setSlashPopoverOpen(false);
        inputRef.current?.focus();
      } else if (e.key === 'Escape') {
        setSlashPopoverOpen(false);
      }
    }
  };

  const selectSlashCommand = (cmd: SlashCommand) => {
    setInputVal(`/${cmd.name} `);
    setSlashPopoverOpen(false);
    inputRef.current?.focus();
  };

  const getRoleColor = (roleId?: string) => {
    if (!roleId) return '#dbdee1';
    const role = roles.find(r => r.id === roleId);
    return role?.color || '#dbdee1';
  };

  // Render Rich Embed
  const renderEmbed = (embed: DiscordEmbed, index: number) => {
    const borderColor = embed.color || '#5865F2';

    return (
      <div
        key={index}
        className="mt-1.5 max-w-xl bg-[#2b2d31] rounded-md p-3.5 border-l-4 text-xs space-y-2.5 shadow-sm overflow-hidden"
        style={{ borderLeftColor: borderColor }}
      >
        {/* Author */}
        {embed.author && (
          <div className="flex items-center gap-2 font-semibold text-white">
            {embed.author.icon_url && (
              <img
                src={embed.author.icon_url}
                alt=""
                className="w-5 h-5 rounded-full"
                referrerPolicy="no-referrer"
              />
            )}
            <span>{embed.author.name}</span>
          </div>
        )}

        {/* Title */}
        {embed.title && (
          <div className="font-bold text-sm text-white tracking-tight leading-snug">
            {embed.url ? (
              <a href={embed.url} target="_blank" rel="noreferrer" className="text-[#00a8fc] hover:underline">
                {embed.title}
              </a>
            ) : (
              embed.title
            )}
          </div>
        )}

        {/* Description */}
        {embed.description && (
          <div className="text-[#dbdee1] leading-relaxed whitespace-pre-line">
            {embed.description}
          </div>
        )}

        {/* Fields */}
        {embed.fields && embed.fields.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1">
            {embed.fields.map((f, i) => (
              <div
                key={i}
                className={f.inline === false ? 'col-span-full' : 'col-span-1'}
              >
                <div className="font-bold text-[#b5bac1] text-[11px] uppercase tracking-wider mb-0.5">
                  {f.name}
                </div>
                <div className="text-[#dbdee1] font-normal leading-normal whitespace-pre-line">
                  {f.value}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Image */}
        {embed.image?.url && (
          <div className="rounded overflow-hidden max-h-60 mt-2 border border-[#3b3e45]">
            <img src={embed.image.url} alt="embed" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
        )}

        {/* Footer & Timestamp */}
        {(embed.footer || embed.timestamp) && (
          <div className="flex items-center gap-1.5 text-[10px] text-[#949ba4] pt-1 border-t border-[#35373c]">
            {embed.footer?.icon_url && (
              <img src={embed.footer.icon_url} alt="" className="w-4 h-4 rounded-full" referrerPolicy="no-referrer" />
            )}
            <span>{embed.footer?.text}</span>
            {embed.footer?.text && embed.timestamp && <span>•</span>}
            {embed.timestamp && <span>Today at {new Date(embed.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
          </div>
        )}
      </div>
    );
  };

  // Render Action Rows / Buttons
  const renderActionRows = (components?: DiscordMessage['components'], msgId?: string) => {
    if (!components || components.length === 0) return null;

    return (
      <div className="mt-2 space-y-1.5">
        {components.map((row, rIdx) => (
          <div key={rIdx} className="flex flex-wrap items-center gap-2">
            {row.components.map(comp => {
              if (comp.type === 'button') {
                const getStyleClass = () => {
                  switch (comp.style) {
                    case 'SUCCESS':
                      return 'bg-[#248046] hover:bg-[#1a6334] text-white';
                    case 'DANGER':
                      return 'bg-[#da373c] hover:bg-[#a1282c] text-white';
                    case 'SECONDARY':
                      return 'bg-[#4e5058] hover:bg-[#6d6f78] text-white';
                    case 'PRIMARY':
                    default:
                      return 'bg-[#5865F2] hover:bg-[#4752c4] text-white';
                  }
                };

                return (
                  <button
                    key={comp.id}
                    onClick={() => handleComponentClick(comp.id, msgId || '')}
                    disabled={comp.disabled}
                    className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed ${getStyleClass()}`}
                  >
                    {comp.emoji && <span>{comp.emoji}</span>}
                    <span>{comp.label}</span>
                  </button>
                );
              }
              return null;
            })}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col bg-[#313338] h-full overflow-hidden relative">
      {/* Top Channel Header */}
      <div className="h-12 px-4 border-b border-[#232428] flex items-center justify-between bg-[#313338] shrink-0 z-10 select-none">
        <div className="flex items-center gap-2 truncate">
          {currentChannel.isTicket ? (
            <Lock className="w-5 h-5 text-[#ED4245] shrink-0" />
          ) : currentChannel.type === 'announcement' ? (
            <Megaphone className="w-5 h-5 text-[#949ba4] shrink-0" />
          ) : (
            <Hash className="w-5 h-5 text-[#949ba4] shrink-0" />
          )}
          <span className="font-bold text-white text-sm tracking-tight">{currentChannel.name}</span>

          {currentChannel.topic && (
            <>
              <div className="h-4 w-[1px] bg-[#3f4147] mx-1" />
              <span className="text-xs text-[#949ba4] truncate max-w-sm hidden sm:inline">
                {currentChannel.topic}
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-3 text-[#b5bac1]">
          <button
            onClick={() => clearChannelMessages(activeChannelId)}
            className="p-1 rounded hover:text-white hover:bg-[#35373c] transition-colors"
            title="Clear Chat History in this channel"
          >
            <Trash2 className="w-4 h-4 text-[#949ba4]" />
          </button>
          <button className="p-1 rounded hover:text-white hover:bg-[#35373c] transition-colors hidden sm:block">
            <Bell className="w-4 h-4" />
          </button>
          <button className="p-1 rounded hover:text-white hover:bg-[#35373c] transition-colors hidden sm:block">
            <Pin className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowMemberList(prev => !prev)}
            className={`p-1 rounded transition-colors ${
              showMemberList ? 'text-white bg-[#35373c]' : 'hover:text-white hover:bg-[#35373c]'
            }`}
            title="Toggle Member List"
          >
            <Users className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Stream Container */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* Welcome Channel Banner for First Message */}
        <div className="pt-4 pb-2 border-b border-[#3b3e45]/50 space-y-1">
          <div className="w-12 h-12 rounded-full bg-[#3f4147] flex items-center justify-center text-white mb-2">
            <Hash className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Welcome to #{currentChannel.name}!
          </h2>
          <p className="text-xs text-[#949ba4]">
            This is the start of the #{currentChannel.name} channel. Send messages, test slash commands, or explore bot configurations.
          </p>
        </div>

        {/* Message Cards */}
        {channelMessages.map(msg => (
          <div key={msg.id} className="flex items-start gap-3.5 group hover:bg-[#2e3035]/50 -mx-4 px-4 py-1.5 rounded transition-colors">
            {/* Avatar */}
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-xs shrink-0 mt-0.5 shadow-sm"
              style={{ backgroundColor: msg.author.avatarColor || '#5865F2' }}
            >
              {msg.author.username.slice(0, 2).toUpperCase()}
            </div>

            {/* Message Body */}
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2 leading-none">
                <span
                  className="font-semibold text-sm hover:underline cursor-pointer"
                  style={{ color: getRoleColor(msg.author.roleId) }}
                >
                  {msg.author.username}
                </span>

                {msg.author.isBot && (
                  <span className="text-[10px] font-bold bg-[#5865F2] text-white px-1.5 py-0.5 rounded leading-none">
                    APP
                  </span>
                )}

                <span className="text-[11px] text-[#949ba4] font-normal">
                  {msg.timestamp}
                </span>
              </div>

              {/* Text content */}
              {msg.content && (
                <div className="text-sm text-[#dbdee1] mt-1 leading-relaxed break-words whitespace-pre-wrap">
                  {msg.content}
                </div>
              )}

              {/* Embeds */}
              {msg.embeds && msg.embeds.map((emb, i) => renderEmbed(emb, i))}

              {/* Interactive Action Rows */}
              {renderActionRows(msg.components, msg.id)}
            </div>
          </div>
        ))}

        {/* Bot Typing Indicator */}
        {isTyping && (
          <div className="flex items-center gap-2 text-xs text-[#949ba4] italic py-1">
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-[#949ba4] rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-[#949ba4] rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-[#949ba4] rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
            <span>{botConfig.name} is thinking...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Slash Command Autocomplete Popover */}
      {slashPopoverOpen && filteredCommands.length > 0 && (
        <div className="absolute left-4 right-4 bottom-18 bg-[#2b2d31] border border-[#3b3e45] rounded-lg shadow-2xl overflow-hidden z-30 max-h-64 flex flex-col">
          <div className="px-3 py-1.5 bg-[#1e1f22] text-[11px] font-bold text-[#949ba4] uppercase tracking-wider flex items-center justify-between border-b border-[#3b3e45]">
            <span className="flex items-center gap-1.5">
              <Command className="w-3.5 h-3.5 text-[#5865F2]" />
              Matching Slash Commands ({filteredCommands.length})
            </span>
            <span className="text-[10px] text-[#72767d]">Use ↑ ↓ to navigate · Tab to select</span>
          </div>

          <div className="overflow-y-auto flex-1 p-1 space-y-0.5">
            {filteredCommands.map((cmd, idx) => {
              const isSelected = idx === selectedSlashIndex;
              return (
                <button
                  key={cmd.name}
                  onClick={() => selectSlashCommand(cmd)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-left text-xs transition-colors ${
                    isSelected ? 'bg-[#404249] text-white' : 'text-[#dbdee1] hover:bg-[#35373c]'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="font-bold text-[#5865F2] font-mono">/{cmd.name}</span>
                    <span className="text-[#949ba4] truncate">{cmd.description}</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#72767d] shrink-0 bg-[#1e1f22] px-1.5 py-0.5 rounded">
                    {cmd.syntax}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Quick Command Suggestions Chips */}
      <div className="px-4 py-1.5 flex items-center gap-1.5 overflow-x-auto text-[11px] text-[#949ba4] select-none shrink-0 border-t border-[#35373c]/40 bg-[#2b2d31]/40">
        <span className="font-semibold text-[#b5bac1] shrink-0">Quick Try:</span>
        {[
          { label: '/help', cmd: '/help' },
          { label: '/rank', cmd: '/rank' },
          { label: '/daily', cmd: '/daily' },
          { label: '/poll', cmd: '/poll "Next community game?"' },
          { label: '/coinflip heads 50', cmd: '/coinflip heads 50' },
          { label: '/serverinfo', cmd: '/serverinfo' },
          { label: '/warn @PixelGamer spam', cmd: '/warn @PixelGamer Repeated spam' },
          { label: '/ticket Help', cmd: '/ticket Billing question' },
        ].map(item => (
          <button
            key={item.label}
            onClick={() => {
              setInputVal(item.cmd);
              inputRef.current?.focus();
            }}
            className="px-2 py-0.5 bg-[#383a40] hover:bg-[#4e5058] text-[#dbdee1] hover:text-white rounded transition-colors font-mono whitespace-nowrap shrink-0"
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Input Box Area */}
      <div className="p-4 pt-1 bg-[#313338] shrink-0">
        <form
          onSubmit={handleFormSubmit}
          className="bg-[#383a40] rounded-lg flex items-center px-4 py-2.5 gap-3 border border-transparent focus-within:border-[#5865F2] transition-colors"
        >
          <button
            type="button"
            className="text-[#b5bac1] hover:text-white transition-colors"
            title="Attach file simulation"
          >
            <PlusCircle className="w-5 h-5" />
          </button>

          <input
            ref={inputRef}
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Message #${currentChannel.name} (type / for commands or ! for prefix)`}
            className="flex-1 bg-transparent text-sm text-[#dbdee1] placeholder-[#72767d] outline-none"
          />

          <button
            type="button"
            onClick={() => {
              setInputVal('/');
              inputRef.current?.focus();
            }}
            className="p-1 text-[#b5bac1] hover:text-white transition-colors text-xs font-mono font-bold bg-[#2b2d31] rounded px-1.5"
            title="Open Slash Commands"
          >
            /
          </button>

          <button
            type="submit"
            disabled={!inputVal.trim()}
            className="text-[#5865F2] hover:text-[#4752c4] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
