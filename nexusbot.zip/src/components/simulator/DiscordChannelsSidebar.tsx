import React from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { DEFAULT_CATEGORIES } from '../../data/defaultData.ts';
import {
  ChevronDown,
  Hash,
  Volume2,
  Megaphone,
  ShieldCheck,
  Ticket as TicketIcon,
  Mic,
  Headphones,
  Settings,
  Sparkles,
  Lock
} from 'lucide-react';

export const DiscordChannelsSidebar: React.FC = () => {
  const { channels, activeChannelId, setActiveChannelId, currentUser, botConfig } = useBot();

  const getChannelIcon = (type: string, isTicket?: boolean) => {
    if (isTicket) return <Lock className="w-4 h-4 text-[#ED4245] shrink-0" />;
    switch (type) {
      case 'announcement':
        return <Megaphone className="w-4 h-4 text-[#949ba4] shrink-0" />;
      case 'voice':
        return <Volume2 className="w-4 h-4 text-[#949ba4] shrink-0" />;
      default:
        return <Hash className="w-4 h-4 text-[#949ba4] shrink-0" />;
    }
  };

  return (
    <div className="w-60 bg-[#2b2d31] flex flex-col shrink-0 select-none border-r border-[#232428] h-full">
      {/* Server Header Dropdown */}
      <div className="h-12 px-4 border-b border-[#1f2023] flex items-center justify-between font-bold text-white shadow-sm hover:bg-[#35373c] transition-colors cursor-pointer">
        <div className="flex items-center gap-1.5 truncate">
          <ShieldCheck className="w-4 h-4 text-[#5865F2] shrink-0" />
          <span className="truncate tracking-tight text-sm">Aegis Central</span>
        </div>
        <ChevronDown className="w-4 h-4 text-[#949ba4]" />
      </div>

      {/* Channel Categories & List */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {DEFAULT_CATEGORIES.map(category => {
          const categoryChannels = channels.filter(c => c.categoryId === category.id);
          if (categoryChannels.length === 0) return null;

          return (
            <div key={category.id} className="space-y-0.5">
              {/* Category Header */}
              <div className="flex items-center gap-1 px-1 py-1 text-[11px] font-bold text-[#949ba4] tracking-wider uppercase">
                <ChevronDown className="w-3 h-3 text-[#949ba4]" />
                <span>{category.name}</span>
              </div>

              {/* Channels in category */}
              <div className="space-y-0.5">
                {categoryChannels.map(channel => {
                  const isActive = channel.id === activeChannelId;

                  return (
                    <button
                      key={channel.id}
                      onClick={() => setActiveChannelId(channel.id)}
                      className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm font-medium transition-colors group ${
                        isActive
                          ? 'bg-[#404249] text-white'
                          : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        {getChannelIcon(channel.type, channel.isTicket)}
                        <span className="truncate">{channel.name}</span>
                      </div>

                      {channel.isTicket && (
                        <span className="text-[10px] font-semibold bg-[#ED4245]/20 text-[#ED4245] px-1.5 py-0.2 rounded border border-[#ED4245]/30">
                          TICKET
                        </span>
                      )}

                      {channel.id === 'c_bot_cmds' && !isActive && (
                        <span className="w-2 h-2 rounded-full bg-[#5865F2]" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* User Footer Bar */}
      <div className="h-[52px] bg-[#232428] px-2 flex items-center justify-between border-t border-[#1f2023] shrink-0">
        <div className="flex items-center gap-2 px-1 py-1 rounded hover:bg-[#35373c] cursor-pointer transition-colors max-w-[130px] truncate">
          <div className="relative shrink-0">
            <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center font-bold text-white text-xs">
              {currentUser.username.slice(0, 2).toUpperCase()}
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#23a55a] ring-2 ring-[#232428]" />
          </div>
          <div className="flex flex-col truncate">
            <span className="text-xs font-semibold text-white truncate leading-tight">
              {currentUser.username}
            </span>
            <span className="text-[10px] text-[#949ba4] truncate leading-tight">
              #{currentUser.discriminator}
            </span>
          </div>
        </div>

        <div className="flex items-center text-[#b5bac1]">
          <button className="p-1.5 rounded hover:bg-[#35373c] hover:text-[#dbdee1] transition-colors" title="Mute Microphone">
            <Mic className="w-4 h-4" />
          </button>
          <button className="p-1.5 rounded hover:bg-[#35373c] hover:text-[#dbdee1] transition-colors" title="Deafen Audio">
            <Headphones className="w-4 h-4" />
          </button>
          <button className="p-1.5 rounded hover:bg-[#35373c] hover:text-[#dbdee1] transition-colors" title="User Settings">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
