import React from 'react';
import { MessageSquare, Plus, Compass } from 'lucide-react';

export const DiscordServerBar: React.FC = () => {
  return (
    <div className="w-[72px] bg-[#1e1f22] flex flex-col items-center py-3 gap-2 shrink-0 select-none border-r border-[#232428]">
      {/* Discord Home / DMs */}
      <div className="relative group flex items-center justify-center">
        <div className="absolute left-0 w-1 bg-white rounded-r transition-all duration-200 h-0 group-hover:h-5" />
        <button
          className="w-12 h-12 rounded-[24px] group-hover:rounded-[16px] bg-[#313338] group-hover:bg-[#5865F2] text-[#dbdee1] group-hover:text-white flex items-center justify-center transition-all duration-200"
          title="Direct Messages"
        >
          <MessageSquare className="w-6 h-6" />
        </button>
      </div>

      {/* Separator */}
      <div className="w-8 h-[2px] bg-[#35363c] rounded-full my-0.5" />

      {/* Active Server (Aegis Central) */}
      <div className="relative group flex items-center justify-center">
        <div className="absolute left-0 w-1 bg-white rounded-r transition-all duration-200 h-10" />
        <button
          className="w-12 h-12 rounded-[16px] bg-[#5865F2] text-white flex items-center justify-center font-bold text-sm shadow-md transition-all duration-200 relative overflow-hidden"
          title="Aegis Central (Active Server)"
        >
          <div className="absolute inset-0 bg-gradient-to-tr from-[#4752c4] to-[#5865F2] flex items-center justify-center font-bold tracking-wider">
            AC
          </div>
          <span className="absolute bottom-1 right-1 w-2.5 h-2.5 bg-[#57F287] rounded-full ring-2 ring-[#1e1f22]" />
        </button>
      </div>

      {/* Add Server Button */}
      <div className="relative group flex items-center justify-center">
        <div className="absolute left-0 w-1 bg-white rounded-r transition-all duration-200 h-0 group-hover:h-5" />
        <button
          className="w-12 h-12 rounded-[24px] group-hover:rounded-[16px] bg-[#313338] group-hover:bg-[#23a55a] text-[#23a55a] group-hover:text-white flex items-center justify-center transition-all duration-200"
          title="Add a Server"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Discover / Compass */}
      <div className="relative group flex items-center justify-center">
        <div className="absolute left-0 w-1 bg-white rounded-r transition-all duration-200 h-0 group-hover:h-5" />
        <button
          className="w-12 h-12 rounded-[24px] group-hover:rounded-[16px] bg-[#313338] group-hover:bg-[#5865F2] text-[#23a55a] group-hover:text-white flex items-center justify-center transition-all duration-200"
          title="Explore Discoverable Servers"
        >
          <Compass className="w-6 h-6 text-[#dbdee1] group-hover:text-white" />
        </button>
      </div>
    </div>
  );
};
