import React, { useState } from 'react';
import { DiscordServerBar } from './DiscordServerBar.tsx';
import { DiscordChannelsSidebar } from './DiscordChannelsSidebar.tsx';
import { DiscordChatArea } from './DiscordChatArea.tsx';
import { DiscordMemberList } from './DiscordMemberList.tsx';

export const DiscordSimulator: React.FC = () => {
  const [showMemberList, setShowMemberList] = useState(true);

  return (
    <div className="flex-1 flex overflow-hidden w-full h-[calc(100vh-61px)]">
      {/* 1. Left server list bar (72px) */}
      <DiscordServerBar />

      {/* 2. Channels sidebar (240px) */}
      <DiscordChannelsSidebar />

      {/* 3. Main chat stream area (flex-1) */}
      <DiscordChatArea
        showMemberList={showMemberList}
        setShowMemberList={setShowMemberList}
      />

      {/* 4. Right member list (240px) */}
      {showMemberList && <DiscordMemberList />}
    </div>
  );
};
