import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { DiscordUser } from '../../types/discord.ts';
import { Shield, AlertTriangle, VolumeX, UserX, X, User } from 'lucide-react';

export const DiscordMemberList: React.FC = () => {
  const { users, roles, sendMessage, botConfig, activeChannelId } = useBot();
  const [selectedUser, setSelectedUser] = useState<DiscordUser | null>(null);

  const userList = Object.values(users);

  // Group users by roles
  const ownerUsers = userList.filter(u => u.roleId === 'role_owner');
  const adminUsers = userList.filter(u => u.roleId === 'role_admin');
  const botUsers = userList.filter(u => u.roleId === 'role_bot' || u.isBot);
  const otherUsers = userList.filter(
    u => u.roleId !== 'role_owner' && u.roleId !== 'role_admin' && u.roleId !== 'role_bot' && !u.isBot
  );

  const getStatusDotColor = (status: DiscordUser['status']) => {
    switch (status) {
      case 'online':
        return 'bg-[#23a55a]';
      case 'idle':
        return 'bg-[#f0b232]';
      case 'dnd':
        return 'bg-[#f23f43]';
      default:
        return 'bg-[#80848e]';
    }
  };

  const getRoleColor = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    return role?.color || '#949ba4';
  };

  const handleQuickModAction = (action: 'warn' | 'mute' | 'kick', targetUser: DiscordUser) => {
    if (action === 'warn') {
      sendMessage(`/warn @${targetUser.username} Excessive spamming in general`);
    } else if (action === 'mute') {
      sendMessage(`/mute @${targetUser.username} 10m Rule violation`);
    } else if (action === 'kick') {
      sendMessage(`/kick @${targetUser.username} Disruptive conduct`);
    }
    setSelectedUser(null);
  };

  const renderUserItem = (user: DiscordUser) => {
    return (
      <button
        key={user.id}
        onClick={() => setSelectedUser(user)}
        className="w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-[#35373c] transition-colors group text-left cursor-pointer"
      >
        <div className="relative shrink-0">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs shadow-sm"
            style={{ backgroundColor: user.avatarColor || '#5865F2' }}
          >
            {user.username.slice(0, 2).toUpperCase()}
          </div>
          <span
            className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-[#2b2d31] ${getStatusDotColor(
              user.status
            )}`}
          />
        </div>

        <div className="flex flex-col truncate flex-1 min-w-0">
          <div className="flex items-center gap-1.5 truncate">
            <span
              className="text-xs font-semibold truncate"
              style={{ color: getRoleColor(user.roleId) }}
            >
              {user.username}
            </span>

            {user.isBot && (
              <span className="text-[10px] font-bold bg-[#5865F2] text-white px-1 py-0.2 rounded shrink-0">
                APP
              </span>
            )}
          </div>

          {user.activity && (
            <span className="text-[11px] text-[#949ba4] truncate font-normal">
              {user.activity}
            </span>
          )}
        </div>
      </button>
    );
  };

  return (
    <div className="w-60 bg-[#2b2d31] flex flex-col shrink-0 select-none border-l border-[#232428] h-full relative">
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {/* Owner */}
        {ownerUsers.length > 0 && (
          <div>
            <div className="px-2 py-1 text-[11px] font-bold text-[#949ba4] tracking-wider uppercase">
              👑 Server Owner — {ownerUsers.length}
            </div>
            <div className="space-y-0.5">{ownerUsers.map(renderUserItem)}</div>
          </div>
        )}

        {/* Admins */}
        {adminUsers.length > 0 && (
          <div>
            <div className="px-2 py-1 text-[11px] font-bold text-[#949ba4] tracking-wider uppercase">
              🛡️ Administrator — {adminUsers.length}
            </div>
            <div className="space-y-0.5">{adminUsers.map(renderUserItem)}</div>
          </div>
        )}

        {/* Bot Apps */}
        {botUsers.length > 0 && (
          <div>
            <div className="px-2 py-1 text-[11px] font-bold text-[#949ba4] tracking-wider uppercase">
              🤖 Bot Apps — {botUsers.length}
            </div>
            <div className="space-y-0.5">{botUsers.map(renderUserItem)}</div>
          </div>
        )}

        {/* Community Members */}
        {otherUsers.length > 0 && (
          <div>
            <div className="px-2 py-1 text-[11px] font-bold text-[#949ba4] tracking-wider uppercase">
              💬 Members — {otherUsers.length}
            </div>
            <div className="space-y-0.5">{otherUsers.map(renderUserItem)}</div>
          </div>
        )}
      </div>

      {/* Mini Profile Popover Modal */}
      {selectedUser && (
        <div className="absolute inset-x-2 bottom-4 bg-[#1e1f22] border border-[#3b3e45] rounded-xl p-4 shadow-2xl z-20 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm"
                style={{ backgroundColor: selectedUser.avatarColor || '#5865F2' }}
              >
                {selectedUser.username.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  {selectedUser.username}
                  <span className="text-xs text-[#949ba4] font-normal">#{selectedUser.discriminator}</span>
                </h4>
                <div className="text-xs text-[#949ba4]">
                  Level <span className="font-semibold text-white">{selectedUser.level}</span> · {selectedUser.xp} XP
                </div>
              </div>
            </div>
            <button
              onClick={() => setSelectedUser(null)}
              className="text-[#949ba4] hover:text-white p-1 rounded hover:bg-[#2b2d31]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="bg-[#2b2d31] p-2.5 rounded-lg text-xs space-y-1 text-[#b5bac1]">
            <div className="flex justify-between">
              <span>Status:</span>
              <span className="font-semibold text-white capitalize">{selectedUser.status}</span>
            </div>
            <div className="flex justify-between">
              <span>Warnings:</span>
              <span className={`font-semibold ${selectedUser.warnings > 0 ? 'text-[#ED4245]' : 'text-[#57F287]'}`}>
                {selectedUser.warnings} / {botConfig.automod.maxWarningsBeforeMute}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Balance:</span>
              <span className="font-semibold text-white">{botConfig.economy.currencySymbol} {selectedUser.balance}</span>
            </div>
          </div>

          {/* Quick Mod Actions (if not bot and not owner) */}
          {!selectedUser.isBot && selectedUser.id !== 'usr_owner' && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[11px] font-bold text-[#949ba4] uppercase tracking-wider">
                Quick Moderation
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => handleQuickModAction('warn', selectedUser)}
                  className="px-2 py-1.5 bg-[#313338] hover:bg-[#FEE75C]/20 hover:text-[#FEE75C] text-xs font-medium rounded transition-colors text-center text-[#dbdee1] flex items-center justify-center gap-1"
                >
                  <AlertTriangle className="w-3 h-3" />
                  Warn
                </button>
                <button
                  onClick={() => handleQuickModAction('mute', selectedUser)}
                  className="px-2 py-1.5 bg-[#313338] hover:bg-[#E67E22]/20 hover:text-[#E67E22] text-xs font-medium rounded transition-colors text-center text-[#dbdee1] flex items-center justify-center gap-1"
                >
                  <VolumeX className="w-3 h-3" />
                  Mute
                </button>
                <button
                  onClick={() => handleQuickModAction('kick', selectedUser)}
                  className="px-2 py-1.5 bg-[#313338] hover:bg-[#ED4245]/20 hover:text-[#ED4245] text-xs font-medium rounded transition-colors text-center text-[#dbdee1] flex items-center justify-center gap-1"
                >
                  <UserX className="w-3 h-3" />
                  Kick
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
