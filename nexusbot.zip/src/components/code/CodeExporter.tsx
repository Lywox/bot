import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import {
  generateDeployCommandsTs,
  generateEnvExample,
  generateIndexTs,
  generatePackageJson,
  generatePythonBot,
  generateReadme,
  generateTsConfig,
} from '../../utils/codeTemplates.ts';
import { Code2, Copy, Check, Download, FileCode, Terminal, Archive, Sparkles, FolderArchive } from 'lucide-react';
import JSZip from 'jszip';

export const CodeExporter: React.FC = () => {
  const { botConfig } = useBot();
  const [selectedFile, setSelectedFile] = useState<string>('src/index.ts');
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const files: Record<string, { content: string; language: string }> = {
    'src/index.ts': {
      content: generateIndexTs(botConfig),
      language: 'typescript',
    },
    'src/deploy-commands.ts': {
      content: generateDeployCommandsTs(botConfig),
      language: 'typescript',
    },
    'package.json': {
      content: generatePackageJson(botConfig),
      language: 'json',
    },
    'tsconfig.json': {
      content: generateTsConfig(),
      language: 'json',
    },
    '.env.example': {
      content: generateEnvExample(),
      language: 'shell',
    },
    'README.md': {
      content: generateReadme(botConfig),
      language: 'markdown',
    },
    'bot.py (Python)': {
      content: generatePythonBot(botConfig),
      language: 'python',
    },
  };

  const currentContent = files[selectedFile]?.content || '';

  const handleCopy = () => {
    navigator.clipboard?.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.replace(' (Python)', '');
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Bot folder root
      const folderName = `${botConfig.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-bot`;
      const root = zip.folder(folderName) || zip;

      // Add project files
      root.file('package.json', generatePackageJson(botConfig));
      root.file('tsconfig.json', generateTsConfig());
      root.file('.env.example', generateEnvExample());
      root.file('.env', generateEnvExample()); // convenient .env ready to fill
      root.file('README.md', generateReadme(botConfig));
      root.file('bot.py', generatePythonBot(botConfig));

      // src subfolder
      const srcFolder = root.folder('src');
      if (srcFolder) {
        srcFolder.file('index.ts', generateIndexTs(botConfig));
        srcFolder.file('deploy-commands.ts', generateDeployCommandsTs(botConfig));
      }

      // Generate blob
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${folderName}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-[#1e1f22] h-[calc(100vh-61px)]">
      {/* File Sidebar */}
      <div className="w-64 bg-[#2b2d31] border-r border-[#232428] p-3 flex flex-col shrink-0 select-none">
        {/* Big 1-Click ZIP Download button */}
        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="w-full mb-3 py-2.5 px-3 bg-[#5865F2] hover:bg-[#4752c4] active:bg-[#3c45a5] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 group cursor-pointer"
        >
          {isZipping ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Generating ZIP...</span>
            </>
          ) : (
            <>
              <FolderArchive className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span>Download Complete ZIP</span>
            </>
          )}
        </button>

        <div className="px-3 py-1.5 text-xs font-bold text-[#949ba4] uppercase tracking-wider flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <FileCode className="w-3.5 h-3.5 text-[#5865F2]" />
            <span>Project Files</span>
          </span>
          <span className="text-[10px] text-[#72767d]">{Object.keys(files).length} files</span>
        </div>

        <div className="space-y-1 mt-1 overflow-y-auto">
          {Object.keys(files).map(filename => (
            <button
              key={filename}
              onClick={() => setSelectedFile(filename)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-mono transition-colors text-left truncate cursor-pointer ${
                selectedFile === filename
                  ? 'bg-[#5865F2] text-white shadow-sm font-semibold'
                  : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
              }`}
            >
              <span>{filename}</span>
            </button>
          ))}
        </div>

        {/* Quick Launch Instructions */}
        <div className="mt-auto bg-[#1e1f22] border border-[#35373c] rounded-xl p-3.5 space-y-2 text-xs">
          <div className="flex items-center gap-1.5 text-white font-bold">
            <Terminal className="w-3.5 h-3.5 text-[#5865F2]" />
            <span>3 Commands to Run</span>
          </div>
          <div className="bg-[#2b2d31] p-2.5 rounded-lg font-mono text-[11px] text-[#dbdee1] space-y-1 overflow-x-auto border border-[#35373c]/60">
            <p className="text-[#57F287]">$ npm install</p>
            <p className="text-[#5865F2]">$ npm run deploy</p>
            <p className="text-[#FEE75C]">$ npm run dev</p>
          </div>
          <p className="text-[10px] text-[#949ba4] leading-relaxed">
            Extract the ZIP, add your token in <code className="text-white">.env</code>, and run the commands above.
          </p>
        </div>
      </div>

      {/* Code Viewer Panel */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Code Bar Header */}
        <div className="h-12 px-6 bg-[#2b2d31] border-b border-[#232428] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-[#5865F2]" />
            <span className="font-mono text-xs font-bold text-white">{selectedFile}</span>
            <span className="text-[11px] text-[#949ba4]">
              ({currentContent.split('\n').length} lines)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              className="px-3 py-1.5 bg-[#5865F2]/20 hover:bg-[#5865F2]/30 text-[#5865F2] hover:text-white border border-[#5865F2]/40 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Archive className="w-3.5 h-3.5" />
              <span>Full ZIP</span>
            </button>

            <button
              onClick={handleDownloadFile}
              className="px-3 py-1.5 bg-[#35373c] hover:bg-[#404249] text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Current File</span>
            </button>

            <button
              onClick={handleCopy}
              className="px-3.5 py-1.5 bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#57F287]" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Code Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#1e1f22]">
          <pre className="font-mono text-xs leading-relaxed text-[#dbdee1] p-4 bg-[#2b2d31]/50 border border-[#35373c] rounded-xl overflow-x-auto whitespace-pre selection:bg-[#5865F2]/40">
            {currentContent}
          </pre>
        </div>
      </div>
    </div>
  );
};

