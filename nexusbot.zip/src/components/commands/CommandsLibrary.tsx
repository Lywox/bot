import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import { ALL_SLASH_COMMANDS } from '../../data/defaultData.ts';
import { Search, Terminal, Play, ShieldAlert, Sparkles, Filter } from 'lucide-react';
import { SlashCommand } from '../../types/discord.ts';

export const CommandsLibrary: React.FC = () => {
  const { sendMessage, setActiveChannelId, setActiveView } = useBot();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Moderation',
    'Utility',
    'Leveling & Economy',
    'Engagement & Fun',
    'Tickets & Support',
  ];

  const filteredCommands = ALL_SLASH_COMMANDS.filter(cmd => {
    const matchesCategory = selectedCategory === 'All' || cmd.category === selectedCategory;
    const matchesSearch =
      cmd.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cmd.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cmd.syntax.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleTestInSimulator = (cmd: SlashCommand) => {
    setActiveChannelId('c_bot_cmds');
    setActiveView('simulator');
    setTimeout(() => {
      sendMessage(cmd.example);
    }, 200);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#1e1f22] h-[calc(100vh-61px)]">
      {/* Top Header & Search */}
      <div className="p-6 bg-[#2b2d31] border-b border-[#232428] space-y-4 shrink-0">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <Terminal className="w-5 h-5 text-[#5865F2]" />
              Commands Catalog & Syntax Reference
            </h1>
            <p className="text-xs text-[#949ba4] mt-1">
              Explore 25+ built-in slash commands. Click "Test in Simulator" to execute any command live.
            </p>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-[#949ba4] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search commands, syntax..."
              className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-[#72767d] focus:outline-none focus:border-[#5865F2]"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#5865F2] text-white shadow-sm'
                  : 'bg-[#1e1f22] text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1] border border-[#3b3e45]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Commands */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCommands.map(cmd => (
            <div
              key={cmd.name}
              className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-4 flex flex-col justify-between hover:border-[#5865F2]/50 transition-colors shadow-sm"
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between">
                  <span className="font-mono text-base font-bold text-white tracking-tight">
                    /{cmd.name}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#1e1f22] text-[#949ba4] border border-[#35373c]">
                    {cmd.category}
                  </span>
                </div>

                <p className="text-xs text-[#dbdee1] leading-relaxed">
                  {cmd.description}
                </p>

                <div className="space-y-1.5 pt-1 text-[11px]">
                  <div className="bg-[#1e1f22] p-2 rounded-lg font-mono text-[#5865F2] border border-[#35373c]/60 overflow-x-auto">
                    {cmd.syntax}
                  </div>

                  {cmd.userPermissions && (
                    <div className="flex items-center gap-1.5 text-[#ED4245] text-[10px] font-semibold">
                      <ShieldAlert className="w-3 h-3" />
                      <span>Requires: {cmd.userPermissions.join(', ')}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-[#3b3e45]/60 mt-3 flex items-center justify-between">
                <span className="text-[10px] text-[#949ba4] font-mono truncate max-w-[150px]">
                  Ex: {cmd.example}
                </span>

                <button
                  onClick={() => handleTestInSimulator(cmd)}
                  className="px-2.5 py-1.5 bg-[#35373c] hover:bg-[#5865F2] text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Test in Chat</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
