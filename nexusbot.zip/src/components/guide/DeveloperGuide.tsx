import React, { useState } from 'react';
import { useBot } from '../../context/BotContext.tsx';
import {
  ExternalLink,
  Shield,
  Key,
  CheckCircle2,
  Copy,
  Check,
  Cpu,
  Globe,
  Sliders,
  Sparkles
} from 'lucide-react';

export const DeveloperGuide: React.FC = () => {
  const { botConfig } = useBot();
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [clientIdInput, setClientIdInput] = useState('123456789012345678');

  // Permissions calculator state
  const [permissions, setPermissions] = useState<Record<string, { bit: bigint; checked: boolean }>>({
    'Administrator': { bit: 8n, checked: true },
    'Manage Server': { bit: 32n, checked: true },
    'Manage Roles': { bit: 268435456n, checked: true },
    'Manage Channels': { bit: 16n, checked: true },
    'Kick Members': { bit: 2n, checked: true },
    'Ban Members': { bit: 4n, checked: true },
    'Moderate Members (Timeout)': { bit: 1099511627776n, checked: true },
    'Send Messages': { bit: 2048n, checked: true },
    'Embed Links': { bit: 16384n, checked: true },
    'Attach Files': { bit: 32768n, checked: true },
    'Read Message History': { bit: 65536n, checked: true },
    'Manage Messages': { bit: 8192n, checked: true },
  });

  const togglePermission = (name: string) => {
    setPermissions(prev => ({
      ...prev,
      [name]: { ...prev[name], checked: !prev[name].checked },
    }));
  };

  // Calculate permissions bit integer
  const totalBit = Object.values(permissions).reduce((acc, curr) => {
    return curr.checked ? acc | curr.bit : acc;
  }, 0n);

  const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientIdInput || 'YOUR_CLIENT_ID'}&permissions=${totalBit.toString()}&scope=bot%20applications.commands`;

  const handleCopyUrl = () => {
    navigator.clipboard?.writeText(inviteUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#1e1f22] p-6 lg:p-10 h-[calc(100vh-61px)]">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="border-b border-[#2b2d31] pb-6 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#5865F2] bg-[#5865F2]/10 px-2 py-0.5 rounded">
              Official Deployment Manual
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            How to Create & Host Your Discord Bot
          </h1>
          <p className="text-sm text-[#949ba4] leading-relaxed">
            Follow this 4-step guide to register your bot application with Discord, configure gateway intents, calculate OAuth2 invite permissions, and run the code 24/7.
          </p>
        </div>

        {/* Step 1 */}
        <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <span className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center font-bold text-white text-sm">
                1
              </span>
              <div>
                <h3 className="text-base font-bold text-white">Create Discord Application</h3>
                <p className="text-xs text-[#949ba4]">Register your bot in the Discord Developer Portal</p>
              </div>
            </div>
            <a
              href="https://discord.com/developers/applications"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 bg-[#35373c] hover:bg-[#5865F2] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <span>Open Developer Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="text-xs text-[#dbdee1] space-y-2 leading-relaxed bg-[#1e1f22] p-4 rounded-lg border border-[#35373c]">
            <p>1. Log in to the <strong>Discord Developer Portal</strong> and click the <strong>"New Application"</strong> button in the top right.</p>
            <p>2. Give your bot a name (e.g. <code>{botConfig.name}</code>) and accept the Developer Terms of Service.</p>
            <p>3. Navigate to the <strong>"Bot"</strong> tab in the left sidebar and click <strong>"Add Bot"</strong> or <strong>"Reset Token"</strong> to generate your secret token.</p>
            <p className="text-[#FEE75C]">⚠️ <em>Never share your bot token publicly. Treat it like a password!</em></p>
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center font-bold text-white text-sm">
              2
            </span>
            <div>
              <h3 className="text-base font-bold text-white">Enable Privileged Gateway Intents</h3>
              <p className="text-xs text-[#949ba4]">Crucial for AutoMod, XP Leveling, and Member Welcomes</p>
            </div>
          </div>

          <div className="text-xs text-[#dbdee1] space-y-3 leading-relaxed bg-[#1e1f22] p-4 rounded-lg border border-[#35373c]">
            <p>On the <strong>Bot</strong> tab in the Developer Portal, scroll down to <strong>"Privileged Gateway Intents"</strong> and toggle ON all 3 switches:</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3 bg-[#2b2d31] rounded-lg border border-[#3b3e45]">
                <div className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-[#57F287]" />
                  <span>Presence Intent</span>
                </div>
                <div className="text-[11px] text-[#949ba4]">Enables tracking member status and activity.</div>
              </div>

              <div className="p-3 bg-[#2b2d31] rounded-lg border border-[#3b3e45]">
                <div className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-[#57F287]" />
                  <span>Server Members</span>
                </div>
                <div className="text-[11px] text-[#949ba4]">Required for join greetings & role automation.</div>
              </div>

              <div className="p-3 bg-[#2b2d31] rounded-lg border border-[#3b3e45]">
                <div className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-[#57F287]" />
                  <span>Message Content</span>
                </div>
                <div className="text-[11px] text-[#949ba4]">Required for AutoMod filters & XP leveling.</div>
              </div>
            </div>
          </div>
        </div>

        {/* Step 3: OAuth2 URL & Permission Calculator */}
        <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center font-bold text-white text-sm">
              3
            </span>
            <div>
              <h3 className="text-base font-bold text-white">OAuth2 Invite Link Generator</h3>
              <p className="text-xs text-[#949ba4]">Calculate required permissions and invite to your server</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#b5bac1] mb-1">
                Your Discord Application Client ID (from "General Information" tab)
              </label>
              <input
                type="text"
                value={clientIdInput}
                onChange={e => setClientIdInput(e.target.value)}
                placeholder="e.g. 123456789012345678"
                className="w-full bg-[#1e1f22] border border-[#3b3e45] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#5865F2]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#b5bac1] mb-2">
                Permission Checkbox Matrix (Calculated Integer: <span className="font-mono text-[#5865F2]">{totalBit.toString()}</span>)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {Object.entries(permissions).map(([name, data]) => (
                  <label
                    key={name}
                    className={`flex items-center gap-2 p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                      data.checked
                        ? 'bg-[#1e1f22] border-[#5865F2] text-white'
                        : 'bg-[#1e1f22]/50 border-[#35373c] text-[#949ba4]'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={data.checked}
                      onChange={() => togglePermission(name)}
                      className="w-4 h-4 text-[#5865F2] rounded focus:ring-0 cursor-pointer"
                    />
                    <span className="truncate">{name}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] space-y-2">
              <span className="text-[11px] font-bold text-[#949ba4] uppercase">Generated Server Invite URL:</span>
              <div className="flex items-center gap-2">
                <input
                  readOnly
                  type="text"
                  value={inviteUrl}
                  className="flex-1 bg-[#2b2d31] border border-[#35373c] rounded px-3 py-1.5 text-xs text-[#5865F2] font-mono outline-none"
                />
                <button
                  onClick={handleCopyUrl}
                  className="px-3.5 py-1.5 bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-semibold rounded transition-colors flex items-center gap-1.5 shadow-sm shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Step 4: Hosting */}
        <div className="bg-[#2b2d31] border border-[#3b3e45] rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center font-bold text-white text-sm">
              4
            </span>
            <div>
              <h3 className="text-base font-bold text-white">24/7 Hosting Options</h3>
              <p className="text-xs text-[#949ba4]">Keep the bot online without leaving your PC powered on</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] space-y-1.5">
              <div className="font-bold text-white text-xs">Railway / Render</div>
              <p className="text-[11px] text-[#949ba4]">
                Push your exported code to GitHub, connect to Railway/Render, set <code>DISCORD_TOKEN</code> env variable, and deploy in 1 click.
              </p>
            </div>

            <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] space-y-1.5">
              <div className="font-bold text-white text-xs">Ubuntu / Linux VPS</div>
              <p className="text-[11px] text-[#949ba4]">
                Use PM2 process manager (<code>pm2 start dist/index.js --name bot</code>) for automatic restart on crash or server reboot.
              </p>
            </div>

            <div className="p-3.5 bg-[#1e1f22] rounded-lg border border-[#3b3e45] space-y-1.5">
              <div className="font-bold text-white text-xs">Docker Container</div>
              <p className="text-[11px] text-[#949ba4]">
                Package into a lightweight Alpine node image and run with <code>docker-compose up -d</code> anywhere.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
