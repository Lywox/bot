import { BotConfig } from '../types/discord.ts';

export function generateReadme(config: BotConfig): string {
  return `# ${config.name} — General Purpose Discord Bot

Built with **Discord.js v14** and TypeScript.

## 🚀 Quick Setup Instructions

### 1. Install Node.js
Ensure you have **Node.js (v18 or v20+)** installed from https://nodejs.org/

### 2. Configure Environment Variables
Copy \`.env.example\` to \`.env\`:
\`\`\`bash
cp .env.example .env
\`\`\`
Edit \`.env\` and add your credentials from the **Discord Developer Portal** (https://discord.com/developers/applications):
- \`DISCORD_TOKEN\`: Found under Application > Bot > Reset Token
- \`CLIENT_ID\`: Found under Application > General Information > Application ID
- \`GUILD_ID\`: Right-click your server icon in Discord and click "Copy Server ID" (enable Developer Mode in Discord settings first)

### 3. Enable Privileged Gateway Intents
In the Discord Developer Portal under **Bot**:
- ✅ Presence Intent
- ✅ Server Members Intent
- ✅ Message Content Intent

### 4. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 5. Register Slash Commands
\`\`\`bash
npm run deploy
\`\`\`

### 6. Start the Bot
\`\`\`bash
npm run dev
\`\`\`

---

## ⚡ Available Commands
- \`/ping\` — Check WebSocket and API latency
- \`/help\` — Interactive command guide
- \`/serverinfo\` — Server metrics, channels, and roles
- \`/userinfo\` — Member profile inspector
- \`/warn <user> [reason]\` — Moderation warning system
- \`/mute <user> <minutes> [reason]\` — Timeout enforcement
- \`/kick <user> [reason]\` — Kick member
- \`/ban <user> [reason]\` — Ban member
- \`/purge <count>\` — Bulk delete messages
- \`/poll <question> <options>\` — Interactive poll
- \`/daily\` — Daily economy coins
- \`/rank\` — User XP and leveling card
- \`/ticket [subject]\` — Open support ticket
`;
}

export function generateTsConfig(): string {
  return JSON.stringify(
    {
      compilerOptions: {
        target: 'ES2022',
        module: 'commonjs',
        moduleResolution: 'node',
        outDir: './dist',
        rootDir: './src',
        strict: true,
        esModuleInterop: true,
        skipLibCheck: true,
        forceConsistentCasingInFileNames: true,
      },
      include: ['src/**/*'],
    },
    null,
    2
  );
}

export function generatePackageJson(config: BotConfig): string {
  return JSON.stringify(
    {
      name: config.name.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-bot',
      version: '1.0.0',
      description: 'Production Discord General Bot powered by Discord.js v14',
      main: 'dist/index.js',
      scripts: {
        dev: 'tsx watch src/index.ts',
        build: 'tsc',
        start: 'node dist/index.js',
        deploy: 'tsx src/deploy-commands.ts',
      },
      dependencies: {
        'discord.js': '^14.16.3',
        dotenv: '^16.4.5',
      },
      devDependencies: {
        '@types/node': '^20.14.0',
        tsx: '^4.16.0',
        typescript: '^5.5.0',
      },
    },
    null,
    2
  );
}

export function generateEnvExample(): string {
  return `# Discord Application Credentials
# Obtain these from the Discord Developer Portal: https://discord.com/developers/applications
DISCORD_TOKEN="YOUR_BOT_TOKEN_HERE"
CLIENT_ID="YOUR_APPLICATION_CLIENT_ID"
GUILD_ID="YOUR_DEVELOPMENT_SERVER_ID"

# Bot Customization
COMMAND_PREFIX="!"
`;
}

export function generateDeployCommandsTs(config: BotConfig): string {
  return `import { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import dotenv from 'dotenv';
dotenv.config();

const commands = [
  // Moderation
  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a formal warning to a server member')
    .addUserOption(opt => opt.setName('user').setDescription('The user to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for warning').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout / mute a member for a set duration')
    .addUserOption(opt => opt.setName('user').setDescription('The user to mute').setRequired(true))
    .addIntegerOption(opt => opt.setName('minutes').setDescription('Duration in minutes').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for timeout'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption(opt => opt.setName('user').setDescription('The user to kick').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for kick'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Permanently ban a user from the server')
    .addUserOption(opt => opt.setName('user').setDescription('The user to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for ban'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk clean up recent messages')
    .addIntegerOption(opt => opt.setName('count').setDescription('Number of messages (1-100)').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  // Utility
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('View full bot commands catalog and documentation'),

  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check WebSocket latency and round-trip response time'),

  new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Display server stats, roles, and member breakdown'),

  new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Inspect a server member profile and join dates')
    .addUserOption(opt => opt.setName('user').setDescription('Member to inspect')),

  new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a community poll with emoji voting buttons')
    .addStringOption(opt => opt.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(opt => opt.setName('options').setDescription('Comma-separated choices').setRequired(true)),

  // Leveling & Economy
  new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Show your level, XP progress, and rank card')
    .addUserOption(opt => opt.setName('user').setDescription('User to view rank for')),

  new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Collect your daily coin allowance'),

  new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your current coin balance'),

  // Tickets
  new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Open a private support ticket with staff')
    .addStringOption(opt => opt.setName('subject').setDescription('Topic of your inquiry')),

  new SlashCommandBuilder()
    .setName('close')
    .setDescription('Close current ticket channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);

async function deploy() {
  try {
    console.log('🔄 Registering slash commands with Discord API...');
    const clientId = process.env.CLIENT_ID!;
    const guildId = process.env.GUILD_ID;

    if (guildId) {
      // Instant guild deployment for testing
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log('✅ Successfully refreshed guild application (/) commands!');
    } else {
      // Global deployment
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('✅ Successfully refreshed global application (/) commands!');
    }
  } catch (error) {
    console.error('❌ Failed to deploy commands:', error);
  }
}

deploy();
`;
}

export function generateIndexTs(config: BotConfig): string {
  return `import {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  Interaction,
  Message,
  ActivityType
} from 'discord.js';
import dotenv from 'dotenv';
dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

// In-Memory Database Store (swap with MongoDB/PostgreSQL in production)
const userLevels = new Map<string, { xp: number; level: number; lastMessage: number }>();
const userBalances = new Map<string, { balance: number; lastDaily: number }>();
const userWarnings = new Map<string, number>();

// Bad words list configured from dashboard
const BAD_WORDS = ${JSON.stringify(config.automod.badWords)};

client.once('ready', (c) => {
  console.log(\`🤖 \${c.user.tag} is online and operational!\`);
  
  c.user.setPresence({
    status: '${config.status}',
    activities: [
      {
        name: '${config.activityName}',
        type: ActivityType.${config.activityType === 'PLAYING' ? 'Playing' : config.activityType === 'LISTENING' ? 'Listening' : config.activityType === 'WATCHING' ? 'Watching' : 'Playing'},
      },
    ],
  });
});

// Member Join Event (Welcome card)
client.on('guildMemberAdd', async (member) => {
  const welcomeChannel = member.guild.channels.cache.find(ch => ch.name.includes('welcome') || ch.id === '${config.welcome.channelId}');
  if (!welcomeChannel || !welcomeChannel.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle('${config.welcome.title}')
    .setDescription(
      \`Hey \${member.toString()}, welcome to **\${member.guild.name}**! You are member **#\${member.guild.memberCount}**.\`
    )
    .setColor('${config.welcome.embedColor}')
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: 'Aegis Welcome Engine' })
    .setTimestamp();

  await welcomeChannel.send({ embeds: [embed] });
});

// Message Event (AutoMod, XP, Auto-responders, Prefix Commands)
client.on('messageCreate', async (message: Message) => {
  if (message.author.bot || !message.guild) return;

  const content = message.content;
  const authorId = message.author.id;

  // 1. AutoMod: Bad Word Filter
  if (${config.automod.badWordsFilter}) {
    const hasBadWord = BAD_WORDS.some(word => content.toLowerCase().includes(word.toLowerCase()));
    if (hasBadWord) {
      await message.delete().catch(() => {});
      const count = (userWarnings.get(authorId) || 0) + 1;
      userWarnings.set(authorId, count);

      const warnEmbed = new EmbedBuilder()
        .setColor('#ED4245')
        .setTitle('⚠️ AutoMod Warning')
        .setDescription(\`\${message.author.toString()}, your message contained prohibited terminology and was removed. (Warning \${count})\`);
      
      const reply = await message.channel.send({ embeds: [warnEmbed] });
      setTimeout(() => reply.delete().catch(() => {}), 5000);
      return;
    }
  }

  // 2. AutoMod: Anti-Invite
  if (${config.automod.antiInvite}) {
    const inviteRegex = /(discord\\.gg|discord\\.com\\/invite)\\//i;
    if (inviteRegex.test(content) && !message.member?.permissions.has(PermissionFlagsBits.ManageGuild)) {
      await message.delete().catch(() => {});
      await message.channel.send(\`⚠️ \${message.author.toString()}, discord invite links are restricted here.\`);
      return;
    }
  }

  // 3. Leveling XP Engine
  if (${config.leveling.enabled}) {
    const now = Date.now();
    const data = userLevels.get(authorId) || { xp: 0, level: 1, lastMessage: 0 };
    if (now - data.lastMessage > ${config.leveling.cooldownSeconds * 1000}) {
      const gained = Math.floor(Math.random() * (${config.leveling.xpPerMessageMax} - ${config.leveling.xpPerMessageMin} + 1)) + ${config.leveling.xpPerMessageMin};
      data.xp += gained;
      data.lastMessage = now;
      const nextLevelXp = data.level * 150;
      if (data.xp >= nextLevelXp) {
        data.level += 1;
        const levelMsg = '${config.leveling.levelUpMessage}'
          .replace('{user}', message.author.toString())
          .replace('{level}', data.level.toString());
        await message.channel.send(levelMsg);
      }
      userLevels.set(authorId, data);
    }
  }

  // 4. Custom Triggers
  const lower = content.toLowerCase();
  if (lower === '!rules') {
    const rulesEmbed = new EmbedBuilder()
      .setTitle('📜 Server Rules')
      .setDescription('1. Be respectful to all members.\\n2. No harassment or hate speech.\\n3. Keep channels on topic.')
      .setColor('#5865F2');
    await message.channel.send({ embeds: [rulesEmbed] });
  }
});

// Slash Command Interactions
client.on('interactionCreate', async (interaction: Interaction) => {
  if (interaction.isButton()) {
    // Ticket button handler
    if (interaction.customId === 'btn_create_ticket') {
      const guild = interaction.guild;
      if (!guild) return;

      const ticketChannel = await guild.channels.create({
        name: \`ticket-\${interaction.user.username.slice(0, 10)}\`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ],
      });

      const ticketEmbed = new EmbedBuilder()
        .setTitle('🎫 Support Ticket Opened')
        .setDescription(\`Hello \${interaction.user.toString()}, thank you for reaching out! Staff will assist you shortly.\`)
        .setColor('#5865F2')
        .setFooter({ text: 'Click Close Ticket below when resolved.' });

      const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId('btn_close_ticket').setLabel('Close Ticket').setStyle(ButtonStyle.Danger).setEmoji('🔒')
      );

      await ticketChannel.send({ embeds: [ticketEmbed], components: [closeRow] });
      await interaction.reply({ content: \`✅ Your ticket has been created in \${ticketChannel.toString()}!\`, ephemeral: true });
      return;
    }

    if (interaction.customId === 'btn_close_ticket') {
      await interaction.reply({ content: '🔒 Closing and archiving ticket in 5 seconds...' });
      setTimeout(async () => {
        await interaction.channel?.delete().catch(() => {});
      }, 5000);
      return;
    }
  }

  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;

  // /ping
  if (commandName === 'ping') {
    const sent = await interaction.reply({ content: 'Pinging...', fetchReply: true });
    const ping = sent.createdTimestamp - interaction.createdTimestamp;
    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'Gateway Latency', value: \`\`\`\${client.ws.ping}ms\`\`\`, inline: true },
        { name: 'Round-trip Latency', value: \`\`\`\${ping}ms\`\`\`, inline: true }
      );
    await interaction.editReply({ content: '', embeds: [embed] });
  }

  // /warn
  if (commandName === 'warn') {
    const target = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const count = (userWarnings.get(target.id) || 0) + 1;
    userWarnings.set(target.id, count);

    const embed = new EmbedBuilder()
      .setTitle('🛡️ Moderation: Warning Issued')
      .setColor('#FEE75C')
      .addFields(
        { name: 'Member', value: target.toString(), inline: true },
        { name: 'Moderator', value: interaction.user.toString(), inline: true },
        { name: 'Reason', value: reason, inline: false },
        { name: 'Total Warnings', value: \`\${count} / 3\`, inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }

  // /daily
  if (commandName === 'daily') {
    const userId = interaction.user.id;
    const current = userBalances.get(userId) || { balance: ${config.economy.startingBalance}, lastDaily: 0 };
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    if (now - current.lastDaily < oneDay) {
      const remainingHours = Math.ceil((oneDay - (now - current.lastDaily)) / (1000 * 60 * 60));
      await interaction.reply({ content: \`⏳ You have already claimed today! Check back in \${remainingHours} hours.\`, ephemeral: true });
      return;
    }

    current.balance += ${config.economy.dailyAmount};
    current.lastDaily = now;
    userBalances.set(userId, current);

    const embed = new EmbedBuilder()
      .setTitle('🪙 Daily Allowance Claimed!')
      .setDescription(\`You collected **${config.economy.currencySymbol} ${config.economy.dailyAmount}** coins!\\nYour new balance is **${config.economy.currencySymbol} \${current.balance}**.\`)
      .setColor('#FEE75C');

    await interaction.reply({ embeds: [embed] });
  }

  // /serverinfo
  if (commandName === 'serverinfo') {
    const guild = interaction.guild!;
    const embed = new EmbedBuilder()
      .setTitle(\`📊 \${guild.name} Statistics\`)
      .setColor('#5865F2')
      .setThumbnail(guild.iconURL() || '')
      .addFields(
        { name: 'Total Members', value: \`\${guild.memberCount}\`, inline: true },
        { name: 'Channels', value: \`\${guild.channels.cache.size}\`, inline: true },
        { name: 'Roles', value: \`\${guild.roles.cache.size}\`, inline: true },
        { name: 'Server ID', value: \`\`\`\${guild.id}\`\`\`, inline: false }
      )
      .setFooter({ text: 'Aegis System Information' });

    await interaction.reply({ embeds: [embed] });
  }
});

client.login(process.env.DISCORD_TOKEN);
`;
}

export function generatePythonBot(config: BotConfig): string {
  return `import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix='${config.prefix}', intents=intents)

# Bad words list
BAD_WORDS = ${JSON.stringify(config.automod.badWords)}

@bot.event
async def on_ready():
    print(f'🤖 {bot.user.name} is ready and listening!')
    await bot.change_presence(
        activity=discord.Game(name="${config.activityName}"),
        status=discord.Status.${config.status == 'dnd' ? 'dnd' : config.status == 'idle' ? 'idle' : 'online'}
    )
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash commands!")
    except Exception as e:
        print(e)

@bot.tree.command(name="ping", description="Check gateway latency")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    embed = discord.Embed(title="🏓 Pong!", color=discord.Color.green())
    embed.add_field(name="Gateway Latency", value=f"\`{latency}ms\`", inline=True)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="warn", description="Warn a member for a rule infraction")
@discord.app_commands.checks.has_permissions(moderate_members=True)
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    embed = discord.Embed(title="🛡️ Warning Issued", color=discord.Color.yellow())
    embed.add_field(name="Member", value=member.mention, inline=True)
    embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
    embed.add_field(name="Reason", value=reason, inline=False)
    await interaction.response.send_message(embed=embed)

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    # AutoMod: Bad Word Filter
    if any(word in message.content.lower() for word in BAD_WORDS):
        await message.delete()
        await message.channel.send(f"⚠️ {message.author.mention}, that language is prohibited here!", delete_after=5)
        return

    await bot.process_commands(message)

bot.run(os.getenv('DISCORD_TOKEN'))
`;
}
